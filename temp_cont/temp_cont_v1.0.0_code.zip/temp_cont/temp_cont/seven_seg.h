/** @file Simple 7-segment display library. Accepts standard putc-like input and
 * generates data sent to a low-level 7-segment write function. This library
 * handles switching between different segments that are connected with a
 * common anode or common cathode.
 *
 * All output is fully double-buffered, allowing for clean output and refreshes.
 *
 * Note that these functions are all fully thread safe.
 *
 * The low-level 7-segment write function must accept a seven_seg_num_disps_t 
 * variable, indicating which display element to activate and raw data denoting
 * which individual segments to activate, encoded as below;
 *           0
 *      __________ 
 *     |          |
 *     |          |
 *    5|         1|
 *     |    6     |
 *     |----------|
 *     |          |
 *    4|         2|
 *     |    3     |
 *     ------------
 *                  7
 * Where the numbers correspond to the bit set in the raw input (0 -> LSB)
 * 
 * This library requires one (or more) seven_seg_driver_t struct(s) (to store
 * internal state data) and an array (acting as a frame-buffer) with as many
 * elements as there are 7-segment displays.
 *
 * TODO: We could possibly place the alphanumeric lookup table in FLASH instead
 * of RAM to reduce memory usage.
 */ 


#ifndef SEVEN_SEG_H_
#define SEVEN_SEG_H_

#include <stdint.h>
#include <stdbool.h>


/** @brief Define to a macro that ensures that code_ is executed atomically */
#include <util/atomic.h>
#define SEVEN_SEG_ATOMIC(code_) ATOMIC_BLOCK(ATOMIC_RESTORESTATE){code_}


/** @brief Internal type to use for representing a given 7-segment display.
 * Must be large enough to represent all the 7-segment displays used, or
 * 2 * the number of all 7-segment displays if using the internal decimal
 * point. */
typedef uint_least8_t seven_seg_num_disp_t;

struct seven_seg_driver_t {
	void (* const raw_segwrite)(const seven_seg_num_disp_t n, const uint_least8_t seg_raw);	//!<- Pointer to function that accepts raw data to output to the n'th 7-segment display, formatted as described above
	const bool dp;								//!<- Set true if a seperate decimal point is available on the displays
	
	
	uint_least8_t curr_disp;					//!<- The current 7-segment display that is active
	seven_seg_num_disp_t char_cnt;				//!<- Number of characters currently in character buffer
	
	const seven_seg_num_disp_t char_buf_len;	//!<- Length of character buffer. Must be at least num_disp if dp is false, otherwise at least 2*num_disp!
	const seven_seg_num_disp_t frame_buf_len;	//!<- Number of 7-segment displays available
	uint_least8_t * const frame_buf;			//!<- Pointer to starting address of frame buffer array to store the current output (raw display data) for all n displays. Must be at least num_disp elements!
	char * const char_buf;						//!<- Pointer to starting address of input buffer array to store the current (and possibly incomplete) output (character data) for all n displays. Must be at least buf_len elements!
};


/** @brief Clears (resets) all internal state for a given driver */
void seven_seg_clr(struct seven_seg_driver_t * const driver);

/** @brief Places a character on the 7-segment output display.
 * Only some input characters will give "useful" output on the display.
 * A CR (0x0D) will reset the cursor position to the first element.
 * A LF (0x0A) will signal that the current input line is complete, copying
 * from the input buffer to the frame buffer.
 * A-Z/a-z, 0-9, "-", ".", and  "," input will draw a character on the display and
 * increment the position counter. Note that "." and "," are special as they
 * will use the decimal point if available.
 * For example, to display "hello world", use an input of "\rhellow world\n"
 * Input after a LF symbol but before a CR will be ignored.
 */
void seven_seg_putc(const char data, struct seven_seg_driver_t * const driver);

/** @brief Idle function to call at the desired switching rate.
* Will switch to the next display and update the output when called. */
void seven_seg_idle(struct seven_seg_driver_t * const driver);

#endif /* SEVEN_SEG_H_ */