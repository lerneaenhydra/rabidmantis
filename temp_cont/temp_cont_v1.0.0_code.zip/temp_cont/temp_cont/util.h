#ifndef UTIL_H_
#define UTIL_H_

#include <avr/pgmspace.h>

/** @brief Macro for giving the number of elements in an array */
#define numel(x) (sizeof(x)/sizeof(x[0]))

/** @brief Macro to generate a complete string line formatted for the 7-segment display, placed in FLASH memory */
#define DISPLINE(x)	"\r"x"\n"

#endif /* UTIL_H_ */