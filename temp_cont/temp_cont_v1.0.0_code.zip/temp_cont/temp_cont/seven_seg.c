#include "seven_seg.h"

#include <stddef.h>

/** @brief Raw 7-segment code for '.' and ',' if using the integrated decimal point */
#define SEVEN_SEG_INT_DP 0x80;
/** @brief Raw 7-segment code for '.' and ',' if simulating the decimal point */
#define SEVEN_SEG_SIM_DP 0x08;
/** @brief Raw 7-segment code for '-' */
#define SEVEN_SEG_HYPHEN 0x40

/** @brief Look-up table for converting A-Z to raw 7-segment equivalent value */
static const char seg_lut_alpha[] = {
	0x77,	/* A */
	0x7C,	/* B */
	0x39,	/* C */
	0x5E,	/* D */
	0x79,	/* E */
	0x71,	/* F */
	0x6F,	/* G */
	0x76,	/* H */
	0x30,	/* I */
	0x1E,	/* J */
	0x76,	/* K */
	0x38,	/* L */
	0x15,	/* M */
	0x54,	/* N */
	0x3F,	/* O */
	0x73,	/* P */
	0x67,	/* Q */
	0x50,	/* R */
	0x6D,	/* S */
	0x78,	/* T */
	0x1E,	/* U */
	0x1C,	/* V */
	0x2A,	/* W */
	0x76,	/* X */
	0x6E,	/* Y */
	0x5,	/* Z */
};

/** @brief Look-up table for converting 0-9 to raw 7-segment equivalent value */
static const char seg_lut_num[] = {
	0x3F,	/* 0 */
	0x06,	/* 1 */
	0x5B,	/* 2 */
	0x4F,	/* 3 */
	0x66,	/* 4 */
	0x6D,	/* 5 */
	0x7D,	/* 6 */
	0x07,	/* 7 */
	0x7F,	/* 8 */
	0x6F	/* 9 */
};

/** @brief Does a quick sanity check to ensure that a driver has been initialized with (hopefully) reasonable pointers */
static bool seven_seg_check_valid_driver( struct seven_seg_driver_t * const driver){
	if(driver == NULL){
		return false;
	}
	if(driver->char_buf == NULL || driver->frame_buf == NULL || driver->raw_segwrite == NULL){
		return false;
	}
	if(driver->frame_buf_len == 0 || driver->char_buf_len == 0){
		return false;
	}
	if(driver->dp){
		if(driver->char_buf_len < 2*driver->frame_buf_len){
			return false;
		}
	}else{
		if(driver->char_buf_len < driver->frame_buf_len){
			return false;
		}
	}
	return true;
}

/** @brief Converts a single character to raw 7-segment encoding */
static char seven_seg_encode_char(const char data, const bool dp){
	if(data == '.' || data == ','){
		if(dp){
			return SEVEN_SEG_INT_DP;
		}else{
			return SEVEN_SEG_SIM_DP;
		}
	}else if(data == '-'){
		return SEVEN_SEG_HYPHEN;
	}else if(data >= '0' && data <= '9'){
		return seg_lut_num[data - '0'];
	}else if(data >= 'a' && data <= 'z'){
		//data input is guaranteed to be lower case
		return seg_lut_alpha[data - 'a'];
	}else{
		return 0;
	}
}

void seven_seg_clr(struct seven_seg_driver_t * const driver){
	if(!seven_seg_check_valid_driver(driver)){
		return;
	}
	//All access to writable elements must be done atomically
	SEVEN_SEG_ATOMIC(														\
		for(seven_seg_num_disp_t i = 0; i < driver->char_buf_len; i++){		\
			*driver->char_buf = 0;											\
			*driver->frame_buf = 0;											\
		}																	\
		driver->curr_disp = 0;												\
		driver->char_cnt = 0;												\
	);
}

void seven_seg_putc(const char data, struct seven_seg_driver_t * const driver){
	if(!seven_seg_check_valid_driver(driver)){
		return;
	}
	switch(data){
		case '\n':
			//Want to terminate the current line and output to the frame buffer
			{
				if(driver->dp){
					//Using decimal point, we need to concatenate characters with the next decimal point to a single display as needed
					seven_seg_num_disp_t i, j;	//i contains the element we are looking at from char_buf, j the element in frame_buf
					SEVEN_SEG_ATOMIC(																																			\
						for(i = 0, j = 0; i < driver->char_cnt && j < driver->frame_buf_len; i++, j++){																			\
							driver->frame_buf[j] = seven_seg_encode_char(driver->char_buf[i], true);																			\
							/* One element added to frame buffer, check if the next character is a decimal point. If so, add this to the current frame buffer element. */		\
							if(i + 1 < driver->char_buf_len){																													\
								if((driver->char_buf[i+1] == '.' || driver->char_buf[i+1] == ',') &&																			\
										(driver->char_buf[i] != '.' && driver->char_buf[i] != ',')){																			\
									i++;																																		\
									driver->frame_buf[j] |= seven_seg_encode_char('.', true);																					\
								}																																				\
							}																																					\
						}																																						\
					);
				}else{
					//Not using dedicated decimal point, every element in char_buf gives exactly one element in raw_mem
					SEVEN_SEG_ATOMIC(																					\
						for(seven_seg_num_disp_t i = 0; i < driver->frame_buf_len && i < driver->char_cnt; i++){		\
							driver->frame_buf[i] = seven_seg_encode_char(driver->char_buf[i], false);					\
						}																								\
					);
				}
			}
			break;
		case '\r':
			//Want to start a new line in the character buffer, wipe all existing data
			SEVEN_SEG_ATOMIC(														\
				driver->char_cnt = 0;												\
				for(seven_seg_num_disp_t i = 0; i < driver->char_buf_len; i++){		\
					driver->char_buf[i] = '\0';										\
				}																	\
				for(seven_seg_num_disp_t i = 0; i < driver->frame_buf_len; i++){	\
					/* Place invalid (0) data in raw memory buffer, will generate*/	\
					/* a blank element in output */									\
					driver->frame_buf[i] = 0;										\
				}																	\
			);
			break;
		default:
			//All alphanumeric (or invalid) input
			{
				char data_cpy = data;
				//Convert all upper-case data to lower-case
				if(data >= 'A' && data <= 'Z'){
					data_cpy |= 0x20;
				}
				if(data_cpy == '.' ||
					data_cpy == ',' ||
					data_cpy == '-' ||
					(data_cpy >= '0' && data_cpy <= '9') ||
					(data_cpy >= 'a' && data_cpy <= 'z')){
					//Got some form of valid (lower-case) input, add to input buffer if there's space
					SEVEN_SEG_ATOMIC(											\
						if(driver->char_cnt < driver->char_buf_len){			\
							driver->char_buf[driver->char_cnt++] = data_cpy;	\
						}														\
					);
				}
				//Else got some form of invalid input or buffer full, ignore
			}
			break;
	}
}

void seven_seg_idle(struct seven_seg_driver_t * const driver){
	if(!seven_seg_check_valid_driver(driver)){
		return;
	}
	SEVEN_SEG_ATOMIC(																		\
		driver->curr_disp++;																\
		if(driver->curr_disp >= driver->frame_buf_len){										\
			driver->curr_disp = 0;															\
		}																					\
		driver->raw_segwrite(driver->curr_disp, driver->frame_buf[driver->curr_disp]);		\
	);
	
}