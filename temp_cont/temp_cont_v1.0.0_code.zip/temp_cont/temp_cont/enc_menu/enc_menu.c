#include "enc_menu.h"
#include <stdlib.h>

static bool enc_menu_check_valid(struct enc_menu_master_t * const menu){
	if(menu == NULL){
		return false;
	}
	if(menu->curr_screen == NULL){
		return false;
	}
	if(menu->inp_fifo->mem == NULL){
		return false;
	}
	return true;
}

void enc_menu_trig_btnevt(const bool btn_state, struct enc_menu_master_t * const menu){
	if(!enc_menu_check_valid(menu)){
		return;
	}
	enum enc_menu_fifo_evt_t evt;
	if(btn_state){
		evt = enc_menu_fifo_evt_pushbtn;
	}else{
		evt = enc_menu_fifo_evt_releasebtn;
	}
	enc_menu_fifo_write(evt, menu->inp_fifo);
}

void enc_menu_trig_rotevt(const bool cw_rot, struct enc_menu_master_t * const menu){
	if(!enc_menu_check_valid(menu)){
		return;
	}
	enum enc_menu_fifo_evt_t evt;
	if(cw_rot){
		evt = enc_menu_fifo_evt_cwrot;
	}else{
		evt = enc_menu_fifo_evt_ccwrot;
	}
	enc_menu_fifo_write(evt, menu->inp_fifo);
}

void enc_menu_idle(struct enc_menu_master_t * const menu){
	if(!enc_menu_check_valid(menu)){
		return;
	}
	enum enc_menu_fifo_evt_t evt;
	if(menu->curr_screen->idle_callback != NULL){
		menu->curr_screen->idle_callback(menu->curr_screen);
	};
	if(menu->curr_screen->idle_str != NULL && menu->puts != NULL){
		menu->puts(menu->curr_screen->idle_str);
	}
	while(enc_menu_fifo_read(&evt, menu->inp_fifo)){
		switch(evt){
			case enc_menu_fifo_evt_pushbtn:
				if(menu->curr_screen->press_callback != NULL){
					menu->curr_screen->press_callback(menu->curr_screen);
				}
				if(menu->curr_screen->press_screen != NULL){
					if(menu->curr_screen->leave_callback != NULL){
						menu->curr_screen->leave_callback(menu->curr_screen);
					}
					menu->curr_screen = menu->curr_screen->press_screen;
					if(menu->curr_screen->enter_callback != NULL){
						menu->curr_screen->enter_callback(menu->curr_screen);
					}
					if(menu->curr_screen->enter_str != NULL && menu->puts != NULL){
						menu->puts(menu->curr_screen->enter_str);
					}
				}
				break;
			case enc_menu_fifo_evt_releasebtn:
				if(menu->curr_screen->release_callback != NULL){
					menu->curr_screen->release_callback(menu->curr_screen);
				}
				if(menu->curr_screen->release_screen != NULL){
					if(menu->curr_screen->leave_callback != NULL){
						menu->curr_screen->leave_callback(menu->curr_screen);
					}
					menu->curr_screen = menu->curr_screen->release_screen;
					if(menu->curr_screen->enter_callback != NULL){
						menu->curr_screen->enter_callback(menu->curr_screen);
					}
					if(menu->curr_screen->enter_str != NULL && menu->puts != NULL){
						menu->puts(menu->curr_screen->enter_str);
					}
				}
				break;
			case enc_menu_fifo_evt_cwrot:
			case enc_menu_fifo_evt_ccwrot:
				//Handle both CW and CCW rotation in the same case section
				if(menu->curr_screen->rot_callback != NULL){
					bool cwrot;
					if(evt == enc_menu_fifo_evt_cwrot){
						cwrot = true;
					}else{
						cwrot = false;
					}
					menu->curr_screen->rot_callback(menu->curr_screen, cwrot);
				}
				{
					struct enc_menu_screen_t * rot_screen;	//Points to either the current screen's CW link or CCW link
					if(evt == enc_menu_fifo_evt_cwrot){
						rot_screen = menu->curr_screen->cw_screen;
					}else{
						rot_screen = menu->curr_screen->ccw_screen;
					}
					if(rot_screen != NULL){
						if(menu->curr_screen->leave_callback != NULL){
							menu->curr_screen->leave_callback(menu->curr_screen);
						}
						menu->curr_screen = rot_screen;
						if(menu->curr_screen->enter_callback != NULL){
							menu->curr_screen->enter_callback(menu->curr_screen);
						}
						if(menu->curr_screen->enter_str != NULL && menu->puts != NULL){
							menu->puts(menu->curr_screen->enter_str);
						}
					}
				}
				break;
			default:
				//Ignore invalid input commands
				break;
		}
	};
}