/** @file Simple FIFO buffer for storing incoming events */ 

#ifndef ENC_MENU_FIFO_H_
#define ENC_MENU_FIFO_H_

#include <stdbool.h>

/** @brief Define to a macro that executes code_ atomically */
//Code example for AVR microcontrollers
#include <util/atomic.h>
#define ENC_MENU_FIFO_ATOMIC(code_) ATOMIC_BLOCK(ATOMIC_RESTORESTATE){code_;}

/** @brief Length of input event FIFO buffer. ENC_MENU_FIFO_LEN - 1 events can be stored.
 * Set to a value of 2^n for speed. */
#define ENC_MENU_FIFO_LEN	32

/** @brief Indexing element used in FIFO buffer. Must be able to represent at least ENC_MENU_FIFO_LEN */
typedef uint_least8_t enc_menu_fifo_idx;

/** @brief All possible incoming events */
enum enc_menu_fifo_evt_t {
	enc_menu_fifo_evt_pushbtn = 0,
	enc_menu_fifo_evt_releasebtn,
	enc_menu_fifo_evt_cwrot,
	enc_menu_fifo_evt_ccwrot
};

/** @brief Memory element for a single FIFO buffer */
struct enc_menu_fifo_t {
	volatile enc_menu_fifo_idx head;
	volatile enc_menu_fifo_idx tail;
	enum enc_menu_fifo_evt_t mem[ENC_MENU_FIFO_LEN];
};

/** @brief Writes a single event to a FIFO memory if there is free space.
 * @param newdata The data to write
 * @param mem The memory structure to write to
 * @return True if the write succeeded */
bool enc_menu_fifo_write(const enum enc_menu_fifo_evt_t evt, struct enc_menu_fifo_t * const mem);

/** @brief Reads a single event from the FIFO memory if there is an available element.
 * @param newdata Pointer to a structure to write the new data to
 * @param mem The memory structure to read from
 * @return True if the read succeeded */
bool enc_menu_fifo_read(enum enc_menu_fifo_evt_t * const evt, struct enc_menu_fifo_t * const mem);

#endif /* ENC_MENU_FIFO_H_ */