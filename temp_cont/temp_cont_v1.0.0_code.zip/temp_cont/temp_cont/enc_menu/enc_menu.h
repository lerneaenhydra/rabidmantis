/** @file FOOBARBAZ
 */ 


#ifndef ENC_MENU_H_
#define ENC_MENU_H_

#include "enc_menu_fifo.h"

/** @brief Data storage element for a single menu screen */
struct enc_menu_screen_t {
	//In general, set a pointer to NULL to disable any action from occurring on that event trigger
	//Some screens may contain references to callback functions to call on certain events
	//All callbacks are called with a pointer to the currently active screen
	void (*enter_callback)(struct enc_menu_screen_t * const screen);				//!<- Callback on entering this screen
	void (*leave_callback)(struct enc_menu_screen_t * const screen);				//!<- Callback on leaving this screen
	void (*press_callback)(struct enc_menu_screen_t * const screen);				//!<- Callback on button press event when screen active
	void (*release_callback)(struct enc_menu_screen_t * const screen);				//!<- Callback on button release event when screen active
	void (*rot_callback)(struct enc_menu_screen_t * const screen, const bool cw);	//!<- Callback on rotation step event
	void (*idle_callback)(struct enc_menu_screen_t * const screen);					//!<- Idle callback, called every time screen is active and enc_menu_idle is called

	//Some screens may trigger a string to render on entering or idle. Rendered after any enter/idle function calls.
	char * enter_str;																//!<- Pointer to string to render on entering this screen
	char * idle_str;																//!<- Pointer to string to render every time screen is active and enc_menu_idle is called
	
	//Some (most) screens may contains references to other screens to transition to on certain events
	struct enc_menu_screen_t * press_screen;										//!<- Screen to transistion to on a button press event
	struct enc_menu_screen_t * release_screen;										//!<- Screen to transistion to on a button release event
	struct enc_menu_screen_t * cw_screen;											//!<- Screen to transistion to on a clockwise step event
	struct enc_menu_screen_t * ccw_screen;											//!<- Screen to transistion to on a counterclockwise step event
};

/** @brief Master data storage element for total system */
struct enc_menu_master_t {
	struct enc_menu_screen_t * curr_screen;		//!<- Pointer to screen that is currently active
	struct enc_menu_fifo_t * const inp_fifo;	//!<- FIFO buffer with pending input operations
	void (*const puts)(char * data);			//!<- Puts function to use when rendering strings (may be NULL to disable string output)
};

/** @brief Function to call on a new encoder button state. Will only queue event in buffer (executes quickly) */
void enc_menu_trig_btnevt(const bool btn_state, struct enc_menu_master_t * const menu);

/** @brief Function to call on a new encoder rotation event. Will only queue event in buffer (executes quickly) */
void enc_menu_trig_rotevt(const bool cw_rot, struct enc_menu_master_t * const menu);

/** @brief Idle function for entire menu subsystem. Acts on queued events and triggers callbacks as appropriate */
void enc_menu_idle(struct enc_menu_master_t * const menu);

#endif /* ENC_MENU_H_ */