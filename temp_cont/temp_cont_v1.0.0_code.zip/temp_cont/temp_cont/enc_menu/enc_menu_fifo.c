#include "enc_menu_fifo.h"
#include <stdlib.h>

bool enc_menu_fifo_write(const enum enc_menu_fifo_evt_t evt, struct enc_menu_fifo_t * const mem){
	if(mem == NULL){
		return false;
	}
	bool retval = false;
	ENC_MENU_FIFO_ATOMIC(											\
			if(((mem->head + 1) % ENC_MENU_FIFO_LEN) != mem->tail){	\
				/* If there's free space in the buffer */			\
				mem->mem[mem->head] = evt;							\
				mem->head = (mem->head + 1) % ENC_MENU_FIFO_LEN;	\
				retval = true;										\
			}														\
	);
	return retval;
}

bool enc_menu_fifo_read(enum enc_menu_fifo_evt_t * const evt, struct enc_menu_fifo_t * const mem){
	if(mem == NULL || evt == NULL){
		return false;
	}
	bool retval = false;
	ENC_MENU_FIFO_ATOMIC(										\
			if(mem->head != mem->tail){							\
				/* If there's something in the buffer */		\
				*evt = mem->mem[mem->tail];						\
				mem->tail = (mem->tail + 1) % ENC_MENU_FIFO_LEN;\
				retval = true;									\
			};													\
	);
	return retval;
}