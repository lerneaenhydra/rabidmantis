/*
 * eeprom_redundant.h
 *
 *  Created on: Mar 6, 2014
 *      Author: desel-lock
 */

#ifndef EEPROM_REDUNDANT_H_
#define EEPROM_REDUNDANT_H_

#include <stdint.h>
#include <stdbool.h>
#include "flex_settings.h"

/** @brief Define to use AVR-libc calls to use device internal EEPROM */
#define AVR_EEP_LIBC

/** @brief Define to add some crude printf output for debugging on AVR platforms */
//#define AVR_PRINT_DEBUG

#ifndef AVR_EEP_LIBC
/** @brief SPI eeprom driver to use for reads/writes */
#define EEPROM_SPI_DRIVER eeprom_drv
#endif

/** @brief The number of copies of a given parameter to store.
 * A value of one implies only one copy; IE. no redundancy, a value of two
 * implies two copies of data; IE one copy may be corrupted and still be able
 * to restore the original data, and so on.*/
#define EEPROM_REDUNDANT_LEVEL	2

#if EEPROM_REDUNDANT_LEVEL < 1
#error EEPROM_REDUNDANT_LEVEL must be at least one
#endif

#if EEPROM_REDUNDANT_LEVEL < 2
#warning No redundancy in saved eeprom settings!
#endif

/** @brief Total number of EEPROM bytes used by this module */
#define EEPROM_SETTING_SIZE (EEPROM_REDUNDANT_LEVEL * FLEX_NUM_PARAM * (sizeof(struct flex_setting_t) + sizeof(uint16_t)) * (CHAR_BIT/8))

/** @brief Attempts to load setting(s) from EEPROM ensuring a valid checksum.
 * Loads settings from some EEPROM base address (byte address),
 * verifying the checksum assumed to be stored after the setting(s), and
 * writing the loaded data to a specific in-system setting. Returns true if the
 * load(s) succeeded (CRC check passed) and false if any failed. In the event
 * of a failed load of multiple settings all the intial settings that had a
 * valid checksum will be loaded, while the failed and all following settings
 * will be aborted.
 *
 * WARNING! THE DEFAULT SETTINGS MUST BE LOADED FROM FLEX_SETTINGS
 * (setting_reset_defaults()) PRIOR TO CALLING!
 *
 * If EEPROM_REDUNDANT_LEVEL > 1 (IE. there is some redundancy) this will scan
 * through all copies of the setting(s) and take action as follows;
 *  - All CRC's valid and equal; copy data to *nv_setting_base_addr, returning
 *      true.
 *  - At least one CRC corrupt and at least one CRC valid; copy valid data to
 *  	corrupt elements, verifying update succeeded, returning false
 *  	otherwise.
 *  - All CRC's corrupt; return false.
 *
 * @param eeprom_base_byte The byte offset for the starting point of
 * 			num_settings eeprom_redundant_settings
 */
bool eeprom_redundant_load(const uint_fast16_t eeprom_base_byte);

/** @brief Saves setting(s) to EEPROM, only writing to EEPROM if new data exists.
 * @param eeprom_base_byte The byte offset for the starting point of
 * 			num_settings eeprom_redundant_settings
 */
bool eeprom_redundant_save(const uint_fast16_t eeprom_base_byte);

#endif /* EEPROM_REDUNDANT_H_ */
