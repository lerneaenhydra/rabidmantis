#ifndef TEMP_CONT_H_
#define TEMP_CONT_H_

#include <stdbool.h>

/** @brief Callback function on raw encoder rotation */
void main_rot_callback(const bool cw);
/** @brief Callback function on raw encoder button press */
void main_btn_callback(const bool btn_state);
/** @brief Returns true if a valid temperature exists to be displayed */
bool main_get_temp_valid(void);

#endif /* TEMP_CONT_H_ */