#include "pwm.h"
#include <stddef.h>

bool pwm_check_drv(struct pwm_t * const drv){
	if(drv == NULL){
		return false;
	}
	if(drv->pwm_set_raw == NULL){
		return false;
	}
	return true;
}

void pwm_init(struct pwm_t * const drv){
	if(!pwm_check_drv(drv)){
		return;
	}
	PWM_ATOMIC(							\
		drv->pwm_int_err = 0;			\
		drv->pwm_ref_duty = 0;			\
		drv->state_shdw = false;		\
	);
}

void pwm_set_duty(struct pwm_t * const drv, pwm_int_ref_t set_pwm_val){
	if(!pwm_check_drv(drv)){
		return;
	}
	//Safely insert new duty cycle to driver
	PWM_ATOMIC(drv->pwm_ref_duty = set_pwm_val);
}

void pwm_idle(struct pwm_t * const drv){
	if(!pwm_check_drv(drv)){
		return;
	}
	
		
	PWM_ATOMIC(																\
		/* Calculate the new error term to apply */							\
		pwm_int_err_t out_scaled;											\
		if(drv->state_shdw){												\
			out_scaled = PWM_RES_MAXVAL;									\
		}else{																\
			out_scaled = 0;													\
		}																	\
		/* Apply this error to the integrator */							\
		drv->pwm_int_err += ((int16_t) drv->pwm_ref_duty) - out_scaled;		\
		/* Drive the output */												\
		if(drv->pwm_int_err < drv->pwm_ref_duty){							\
			drv->pwm_set_raw(false);										\
			drv->state_shdw = false;										\
		}else{																\
			drv->pwm_set_raw(true);											\
			drv->state_shdw = true;											\
		}																	\
	);
}