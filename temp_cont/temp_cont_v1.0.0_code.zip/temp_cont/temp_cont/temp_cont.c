/**
 * Temp cont
 * A simple temperature controller with adjustable temperature/power output.
 * Be sure to use fuse settings;
 * WDWP = 8CLK
 * WDP = 8KCLK
 * BOOTRST = APPLICATION
 * BODPD = CONTINUOUS
 * RSTDISBL = [ ]
 * SUT = 64MS
 * WDLOCK = [X]
 * BODACT = CONTINUOUS
 * EESAVE = [ ]
 * BODLVL = 3V0
 * FDACT5 = [ ]
 * FDACT4 = [ ]
 * VALUE = 0x3F
 * 
 * FUSEBYTE1 = 0x0A (valid)
 * FUSEBYTE2 = 0xFE (valid)
 * FUSEBYTE4 = 0xF1 (valid)
 * FUSEBYTE5 = 0xE8 (valid)
 * FUSEBYTE6 = 0xFF (valid)
 */ 

const char fusedata[] __attribute__((section(".fuse"))) = {0xFF, 0x0A, 0xFD, 0xFF, 0xF1, 0xE8, 0xFF};

#include "temp_cont.h"
#include <avr/io.h>
#include <util/atomic.h>
#include <avr/wdt.h>
#include <stdio.h>
#include <avr/pgmspace.h>

#include "board.h"
#include "seven_seg.h"
#include "util.h"
#include "config.h"
#include "systime/systime.h"
#include "rotary_enc.h"
#include "globals.h"
#include "flex_settings/flex_settings.h"
#include "ds18b20_single/ds18b20_single.h"
#include "flex_settings/eeprom_redundant.h"
#include "pwm/pwm.h"

/** @brief Idle function that handles sampling the temperature sensor, updating the stored temperature when appropriate, and handling error events */
void main_temp_idle(void);

/** @brief Applies a control law based on the current temperature and handles over/under temperature errors */
void main_tempcalc(void);

//Callback setup for coupling base rotary encoder lib to encoder menu system
void main_rot_callback(const bool cw){
	enc_menu_trig_rotevt(cw, &g_menu);
}
void main_btn_callback(const bool btn_state){
	enc_menu_trig_btnevt(btn_state, &g_menu);
}

/** @brief Error state handler and timeout functionality */
static systime_t errstate_d = 0;
static bool errstate_latch = true;	//Set true to force an error clear on startup

/** @brief Triggers an error state. Returns true if we were not in an error state before */
bool main_errtrig(void){
	bool retval;
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
		errstate_d = systime_get_delay(MS2US(ERR_OUT_DELAY_ms));
		retval = !errstate_latch;
		errstate_latch = true;
		board_set_errstate(true);
	}
	return retval;
}

/** @brief Error handler, resets the error state if we have not triggered an error in some timeout time */
void main_errhndl(void){
	bool errclr = false;
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
		if(errstate_latch){
			if(systime_get_delay_passed(errstate_d)){
				errstate_latch = false;
				errclr = true;
			}
		}
	}
	if(errclr){
		board_set_errstate(false);
		printf_P(PSTR("Error condition resolved.\n"));
	}
}

/** @brief Crude indicator that the temperature probe is connected and the TCT parameter contains a valid value to display */
static bool main_temp_valid = false;
bool main_get_temp_valid(void){
	bool retval;
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE){retval = main_temp_valid;};
	return retval;
}

/************************************************************************/
/* Start main()                                                         */
/************************************************************************/
int main(void){
	BUILD_BUG_ON(EEPROM_SETTING_SIZE > EEPROM_TOTAL_SIZE);
	ATOMIC_BLOCK(ATOMIC_FORCEON){
		board_init_io();
		board_init_clk();
		board_uart_init();
		board_init_timer();
		board_en_pmic_all();
		setting_reset_defaults();
		
		//If we got a WDT-triggered reset, enter an infinite loop display error status on the display
		if(board_get_error_reset()){
			board_set_errstate(true);
			NONATOMIC_BLOCK(ATOMIC_RESTORESTATE){
				for(;;){
					fprintf_P(&seg_str, PSTR("\rSYS\n"));
					systime_t delay = systime_get_delay(S2US(1));
					while(!systime_get_delay_passed(delay)){
						wdt_reset();
					}
					fprintf_P(&seg_str, PSTR("\rERR\n"));
					delay = systime_get_delay(S2US(1));
					while(!systime_get_delay_passed(delay)){
						wdt_reset();
					}
				}	
			}
		}
		stdin = &uart_str;
		stdout = &uart_str;
		printf_P(PSTR(STARTUP_MESSAGE));
		
		if(ds18b20_single_init(&probe_drv)){
			printf_P(PSTR("Probe detected and configured.\n"));
		}else{
			printf_P(PSTR("Probe comms/configuration error on startup!\n\n"));
		}
		g_sdl_ref = S2US(setting_get_real(PARAM_SDL_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO));	//Apply some reasonable default value for SDL until we have loaded the setting from EEPROM
	}
	
	if(!eeprom_redundant_load(0)){
		main_errtrig();
		//EEPROM is corrupt =(
		//Seed with some default parameters on acknowledgment
		fprintf_P(&seg_str, PSTR("\rCRC\n"));
		printf_P(PSTR(CRC_FAIL_MSG));
		//Wait for button press/release. This also queues a button release event bringing us to the setup menu ;)
		while(!rotary_enc_get_btnstate(&g_rot_enc)){
			wdt_reset();
		}
		while(rotary_enc_get_btnstate(&g_rot_enc)){
			wdt_reset();
		}
		
		setting_reset_defaults();
		eeprom_redundant_save(0);
		//Display a reset indicator
		systime_t rst_delay = systime_get_delay(S2US(3));
		fprintf_P(&seg_str, PSTR("\rRST\n"));
		while(!systime_get_delay_passed(rst_delay)){
			wdt_reset();
		}
	}
	
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
		//Apply stored SDL parameter
		g_sdl_ref = S2US(setting_get_real(PARAM_SDL_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO));	//Apply the stored SDL parmeter
	}
	
	pwm_init(&g_pwm);

    for(;;){
		wdt_reset();
		enc_menu_idle(&g_menu);
		main_temp_idle();
		main_errhndl();
	    }
}

void main_temp_idle(void){
	static bool newsamp_pend = false;				//Set true if a new temperature sample is pending
	static systime_t temp_conv_d = 0;				//Time remaining until temperature sampling is complete
	static uint_least8_t failed_comms_cnt = 0;		//Number of sucessive failed communications attempts
	
	//Periodically get a new temperature value
	if(!newsamp_pend){
		temp_conv_d = systime_get_delay(MS2US(TSENSE_SAMP_DELAY_ms));
		ds18b20_start_meas(&probe_drv);
		newsamp_pend = true;
	}
	
	if(newsamp_pend && systime_get_delay_passed(temp_conv_d)){
		int_fast16_t temp_raw;
		const bool success = ds18b20_get_meas(&probe_drv, &temp_raw);
		if(success){
			failed_comms_cnt = 0;
			float temp_degc = temp_raw / 16.0;
			setting_set_real(PARAM_TCT_IDX, FLEX_PARAM_VAL, temp_degc, FLEX_FORCE_SUDO);
			ATOMIC_BLOCK(ATOMIC_RESTORESTATE){main_temp_valid = true;};
			main_tempcalc();	//Apply temperature control law
		}else{
			ATOMIC_BLOCK(ATOMIC_RESTORESTATE){main_temp_valid = false;};
			if(failed_comms_cnt > FAILED_COMMS_MAX){
				main_errtrig();
				printf_P(PSTR("Probe communications failure!\n"));
			}else{
				failed_comms_cnt++;
			}
		}
		newsamp_pend = false;
	}
}

void main_tempcalc(void){
	//Apply control law and check for temperature out-of-bounds error condition
	static float curr_temp_hyst = 0;	//Current temperature, with hysteresis
	
	const float curr_temp = setting_get_real(PARAM_TCT_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
	const float max_temp = setting_get_real(PARAM_THI_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
	const float min_temp = setting_get_real(PARAM_TLO_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
	const float hyst_temp = setting_get_real(PARAM_THY_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
	
	const float max_pwr = setting_get_real(PARAM_PHI_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
	const float min_pwr = setting_get_real(PARAM_PLO_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
	const float ct_pwr = setting_get_real(PARAM_PCT_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
	
	const float low_err = setting_get_real(PARAM_ELO_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
	const float high_err = setting_get_real(PARAM_EHI_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
	
	float out_pwr;
	
	#ifdef DEBUG_PRINT
	printf_P(PSTR("Got measured temp %g; "), curr_temp);
	#endif
	if(curr_temp - hyst_temp/2.0f > curr_temp_hyst){
		curr_temp_hyst = curr_temp - hyst_temp/2.0f;
	}
	if(curr_temp + hyst_temp/2.0f < curr_temp_hyst){
		curr_temp_hyst = curr_temp + hyst_temp/2.0f;
	}
	
	#ifdef DEBUG_PRINT
	printf_P(PSTR("gives hysteresis-adjusted temperature %g; "), curr_temp_hyst);
	#endif
	if(curr_temp_hyst <= min_temp){
		out_pwr = min_pwr;
		#ifdef DEBUG_PRINT
		printf_P(PSTR("is below min temp, applying power %g\n"), out_pwr);
		#endif
	}else if(curr_temp_hyst >= max_temp){
		out_pwr = max_pwr;
		#ifdef DEBUG_PRINT
		printf_P(PSTR("is above max temp, applying power %g\n"), out_pwr);
		#endif
	}else{
		//Temperature lies in range of min_temp < temp < max_temp
		const float rel_temp = (curr_temp_hyst - min_temp)/(max_temp - min_temp);	//Normalized temperature, 0 -> min temp; 1 -> max temp
		out_pwr = min_pwr + rel_temp * (max_pwr - min_pwr);						//Linear mapping of output power based on normalized temperature
		#ifdef DEBUG_PRINT
		printf_P(PSTR("is in linear range, applying power %g"), out_pwr);
		#endif
		if(out_pwr < ct_pwr){													//Clamp output power to minimum power if below power cutoff
			out_pwr = min_pwr;
			#ifdef DEBUG_PRINT
			printf_P(PSTR(", clamping to cutoff power %g"), out_pwr);
			#endif
		}
		#ifdef DEBUG_PRINT
		printf_P(PSTR("\n"), out_pwr);
		#endif
	}
	
	pwm_set_duty(&g_pwm, PWM_FLT2DUTY(out_pwr/100.0f));
	
	//Apply high/low temperature error output directly on the current temperature
	if(curr_temp < low_err){
		if(main_errtrig()){
			printf_P(PSTR("Low-temperature error triggered!\n"));
		}
	}
	if(curr_temp > high_err){
		if(main_errtrig()){
			printf_P(PSTR("High-temperature error triggered!\n"));
		}
	}
}

ISR(DISP_vect){
	seven_seg_idle(&g_disp);
}

ISR(TIMER_vect){
	systime_update();
	rotary_enc_idle(&g_rot_enc);
	
	//Run PWM output occasionally
	static systime_t pwm_delay = 0;
	static systime_t last_g_sdl_ref = 0;
	ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
		//If the minimum switch delay is changed to a lower value than we have seen, update the remaining switch delay immediately
		//(This avoids an issue where we change from a switch delay of say 60 seconds and don't want to wait for it to time out)
		if(g_sdl_ref < last_g_sdl_ref){
			pwm_delay = systime_get_delay(g_sdl_ref);
		}
		last_g_sdl_ref = g_sdl_ref;
		
		if(systime_get_delay_passed(pwm_delay)){
			pwm_delay = systime_get_delay(g_sdl_ref);
			pwm_idle(&g_pwm);
		}	
	}
}