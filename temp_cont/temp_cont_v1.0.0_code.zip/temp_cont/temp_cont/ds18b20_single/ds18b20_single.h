/** @file Simple library for accessing a single DS18B20/DS18S20 probe.
 * Accesses and reads the temperature from a single DS18B20/DS18S20 device,
 * allowing for controlling the conversion accuracy for the B device series.
 * Current implementation is hard-coded for parasite-powered devices!
 */ 


#ifndef DS18B20_SINGLE_H_
#define DS18B20_SINGLE_H_

#include <stdbool.h>
#include <stdint.h>

/** @brief Define/include to generate code sections that are guaranteed atomic */
#include <util/atomic.h>
#define DS18B20_ATOMIC(code_)	ATOMIC_BLOCK(ATOMIC_RESTORESTATE){code_;}
	
/** @brief Define/include to generate code sections that delay for a given time */
#include <util/delay.h>
#define DS18B20_DELAY_us(x)		_delay_us(x)

/** @brief Enumerated type for controlling the bit depth of a probe */
enum ds18b20_single_bitdepth_t {ds18b20_single_bitdepth_9bit = 0,		//!<- Request 9-bit temperature resolution
								ds18b20_single_bitdepth_10bit,			//!<- Request 10-bit temperature resolution
								ds18b20_single_bitdepth_11bit,			//!<- Request 11-bit temperature resolution
								ds18b20_single_bitdepth_12bit,			//!<- Request 12-bit temperature resolution
								ds18b20_single_bitdepth_num};			//!<- Number of bit depths available

/** @brief Driver struct for a single DS18x20 probe */
struct ds18b20_single_drv_t {
	void (*const hp_drive)(bool);	//!<- Pointer to function to control the high-power output. If called with a true argument must drive the 1-wire bus to a hard high state. If called with false argument must revert to pullup state. Must execute in < 1us.
	void (*const lp_drive)(bool);	//!<- Pointer to function to drive the bus during low-power operation. If called with a true argument should tri-state the output (leaving the pullup enabled). If called with false argument should bring the bus low. Must execute in < 1us.
	bool (*const get_bus)(void);	//!<- Pointer to function to get the current bus state. (Low -> false, high -> true)
	
	const enum ds18b20_single_bitdepth_t bitdepth;		//!<- The desired bit-depth for temperature conversions (only applicable for B type probes)
};

/** @brief Byte to skip the ROM matching command */
#define DS18B20_SKIP_ROM	0xCC

/** @brief Byte to trigger a write to scratchpad command */
#define DS18B20_WRITE_PAD	0x4E

/** @brief Byte to initiate a temperature conversion on device */
#define DS18B20_COMM_CONV	0x44

/** @brief Byte to read the entire scratchpad */
#define DS18B20_READ		0xBE

/** @brief Config register values for different resolutions */
#define DS18B20_CONF_9BIT	0x1F
#define DS18B20_CONF_10BIT	0x3F
#define DS18B20_CONF_11BIT	0x5F
#define DS18B20_CONF_12BIT	0x7F

/** @brief Number of data bytes in each read */
#define DS18B20_NUM_DATA_BYTES	9

/** @brief Initializes and checks for presence of a probe.
 * @param drv The probe driver to use
 * @return True on success, false else */
bool ds18b20_single_init(struct ds18b20_single_drv_t * const drv);

/** @brief Requests a single temperature sample/conversion.
 * The temperature can be read using ds18b20_start_meas after some time depending on the bit depth;
 *	- 9 bit; 93.75ms
 *	- 10 bit; 187.5ms
 *	- 11 bit; 375ms
 *	- 12 bit; 750ms
 * @param drv The probe driver to use
 * @return True on success, false otherwise */
bool ds18b20_start_meas(struct ds18b20_single_drv_t * const drv);

/** @brief Requests the result of a previously completed conversion.
 * Note that there is no protection to ensure that a conversion has been
 * triggered or that the conversion is complete!
 * @param drv The probe driver to use
 * @param meastemp_raw The raw temperature as returned by the probe (degC * 16)
 * @return True on success, false otherwise */
bool ds18b20_get_meas(struct ds18b20_single_drv_t * const drv, int_fast16_t * const meastemp_raw);


#endif /* DS18X20_SINGLE_H_ */