/*
 * config.h
 *
 * Created: 1/31/2015 9:38:08 PM
 *  Author: win7vm
 */ 


#ifndef CONFIG_H_
#define CONFIG_H_

#define BUILD_BUG_ON(x)				((void)sizeof(char[1 - 2*!!(x)]))

/** @brief Define to print temperature calculation/control law data to serial interface */
//#define DEBUG_PRINT

/** @brief Total EEPROM size in device */
#define EEPROM_TOTAL_SIZE			512

/** @brief Systick timer period [microseconds] */
#define SYSTICK_PER_us				1000

/** @brief Seven-segment display timer period [microseconds] */
#define DISP_PER_us					100

/** @brief Debounce time for encoder pushbutton [milliseconds] */
#define BOARD_DEBOUNCE_TIME_ms		50

/** @brief Number of A/B transitions per encoder detent */
#define BOARD_ENC_DIVISOR			2

/** @brief Sampling period for encoder input [milliseconds] */
#define BOARD_ENC_SAMPLE_PER_us		(SYSTICK_PER_us)

/** @brief Baud rate for debug UART communication */
#define BOARD_UART_BAUD				(115200)

/** @brief Increment value for temperature-type parameters */
#define PARAM_TEMP_ENC_SCALE		(0.1f)
/** @brief Rounding accuracy for temperature-type parameters. Parameter is inverse of net accuracy, ie 10 -> accurate to 0.1 */
#define PARAM_TEMP_ENC_RND			(10)
/** @brief Increment value for power-type parameters */
#define PARAM_PWR_ENC_SCALE			(1.0f)
/** @brief Rounding accuracy for power-type parameters. Parameter is inverse of net accuracy, ie 10 -> accurate to 0.1 */
#define PARAM_PWR_ENC_RND			(1)
/** @brief Increment value for time-type parameters with value < 1 second. Each increasing decade scales this parameter by one power of ten */
#define PARAM_TIME_ENC_SCALE_s		(0.01f)
//Accuracy for time-type parameters hard-coded in enc_callbacks.c

/** @brief Minimum temperature parameters can be set to [degC] */
#define PARAM_MINTEMP_deg			(-55.0f)

/** @brief Maximum temperature parameters can be set to [degC] */
#define PARAM_MAXTEMP_deg			(125.0f)

/** @brief Minimum power parameters can be set to [%] */
#define PARAM_MINPWR				(0.0f)

/** @brief Maximum power parameters can be set to [%] */
#define PARAM_MAXPWR				(100.0f)

/** @brief Default SDL parameter value [s] */
#define PARAM_SDL_DEF_s				(1.0f)

/** @brief Minimum SDL parameter value [s] */
#define PARAM_SDL_MIN_s				(0.01f)

/** @brief Maximum SDL parameter value [s] */
#define PARAM_SDL_MAX_s				(60.0f)

/** @brief Scaling coefficient when adjusting a parameter and the rotary encoder button is pressed */
#define ROT_ENC_PRESSED_SCALE		(10)

/** @brief Update period for displaying current measured temperature */
#define DISP_TCT_PER_ms				(100)

/** @brief Sanple delay (start of conversion to conversion complete) for temperature sensor */
#define	TSENSE_SAMP_DELAY_ms		(800)

/** @brief Maximum number of failed temperature sensor communications attempts before entering error state */
#define FAILED_COMMS_MAX			3

/** @brief Minimum time to hold error output in error state after an error condition */
#define ERR_OUT_DELAY_ms			2500

#if ERR_OUT_DELAY_ms <  FAILED_COMMS_MAX * TSENSE_SAMP_DELAY_ms
#error ERR_OUT_DELAY_ms is too small!
#endif

/** @brief Core clock speed */
#ifndef F_CPU
#define F_CPU						(32000000ULL)
#endif

/** @brief Current software version */
#define SW_VERSION					"1.0.1"


#define STARTUP_MESSAGE												\
"\n\n\n"															\
" _____                  ___         _\n"							\
"|_   _|__ _ __  _ __   / __|___ _ _| |_\n"							\
"  | |/ -_) '  \\| '_ \\ | (__/ _ \\ ' \\  _|\n"					\
"  |_|\\___|_|_|_| .__/  \\___\\___/_||_\\__|\n"					\
" ___      _    |_|  _   __  __          _   _\n"					\
"| _ \\__ _| |__(_)__| | |  \\/  |__ _ _ _| |_(_)___\n"				\
"|   / _` | '_ \\ / _` | | |\\/| / _` | ' \\  _| (_-<\n"			\
"|_|_\\__,_|_.__/_\\__,_| |_|  |_\\__,_|_||_\\__|_/__/\n"			\
"\n"																\
"Version "SW_VERSION", compiled on " __DATE__ ", at "__TIME__".\n"	\
"See www.rabidmantis.se for more information.\n"

#define CRC_FAIL_MSG	"Unrecoverable CRC error! All settings will be reset with factory defaults on button press.\n"

#define BOARD_DEBOUNCE_INT_THRS	((1000ULL * BOARD_DEBOUNCE_TIME_ms)/BOARD_ENC_SAMPLE_PER_us)

/** @brief Converts a minimum hold time in seconds to a hold value as used by pwm.h */
#define PWM_S2HOLD(x)	((x) * (SYSTICK_PER_us) * 1.0f)

#endif /* CONFIG_H_ */