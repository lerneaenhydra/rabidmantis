/** @file General-purpose rotary encoder (with optional pushbutton) library */ 

#ifndef ROTARY_ENC_H_
#define ROTARY_ENC_H_

#include <stdbool.h>
#include <stdint.h>

struct rotary_enc_t {
	/************************************************************************/
	/*               Variables that must be initialized at compile-time     */
	/************************************************************************/
	void (* const enc_rot_callback)(const bool cw_rot);				//!<- Callback function, called on CW/CCW rotation detection of a single step (bool set on CW rotation, cleared else)
	void (* const enc_btn_callback)(const bool btn_state);			//!<- Callback function, called on button state change detection (bool set to new button state)
	
	bool(* const enc_get_btnstate)(void);							//!<- Function to call that returns the current raw (not debounced) button state. If a button is not desired set function pointer to dummy function returning some constant value.
	void(* const enc_get_rotstate)(bool * const a, bool * const b);	//!<- Function to call that returns the current raw (unfiltered) encoder phase state. If A leads B this is regarded as clockwise.
	
	const uint_least8_t enc_divisor;			//The number of A/B transitions per output CW/CCW rotation step (IE. set to 1 to output steps as fast as possible, 4 to output a step after a full A/B period, etc)
	const uint_least16_t btn_bounce_int_thrs;	//The integration threshold for the button
	
	/************************************************************************/
	/*              Variables that are set by rotary_enc_init()             */
	/************************************************************************/
	uint_least8_t enc_pos;						//The current internal encoder state
	bool last_dir_cw;							//If true, the last sampled direction was clockwise
	uint_least8_t curr_enc_step;				//Internal state-keeping variable, increments once per CW/CCW rotation step modulo enc_divisor
	bool btn_state_debounced;					//The current debounced button state
	uint_least16_t btn_state;					//The current integrated button state
};

/** @brief Idle function for all rotary encoders.
 * Call with a given encoder to parse input and potentially call callback functions.
 * Must be called at a fixed period. Debouncing time for the button input is set by
 * encstate.btn_bounce_int_thrs. Be sure to call fast enough to sample the rotary
 * encoder at the maximum speed.
 *  */
void rotary_enc_idle(struct rotary_enc_t * const encstate);

/** @brief Returns the current debounced rotary encoder button state */
bool rotary_enc_get_btnstate(struct rotary_enc_t * const encstate);

/** @brief Initializes the non-constant driver elements to default values */
void rotary_enc_init(struct rotary_enc_t * const encstate);

#endif /* ROTARY_ENC_H_ */