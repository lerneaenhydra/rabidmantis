#ifndef ONEWIRE_H_
#define ONEWIRE_H_

#include "ds18b20_single.h"
#include <stddef.h>

/** @brief Enumerated type for controlling the type of output drive for a single output byte */
enum onewire_drive_t {onewire_drive_lowpwr = 0, onewire_drive_highpwr};
	
/** @brief Time (us) for the reset pulse sent from the master */
#define	ONEWIRE_RESET_us					480

/** @brief Time (us) between reset pulse and first detection check */
#define ONEWIRE_RESET_PRESENCE_MIN_us		15

/** @brief Time (us) between first detection check and eventual time-out */
#define ONEWIRE_RESET_PRESENCE_WAIT_us		(60 - ONEWIRE_RESET_PRESENCE_MIN_us)

/** @brief Time (us) between detection check finished and continuing (a padding time) */
#define ONEWIRE_RESET_POSTPAD_us			(480 - ONEWIRE_RESET_PRESENCE_MIN_us)

/** @brief Time (us) to wait after a read for the timeslot to expire */
#define ONEWIRE_TIME_READ_TIMESLOT_DELAY_us	100

/** @brief Time (us) for the master to hold the bus low to initiate a read bit command */
#define ONEWIRE_TIME_READ_HOLD_LOW_us		2

/** @brief Time (us) after initiating a read for the master to sample the bus for the bit statis */
#define ONEWIRE_TIME_READ_SAMPLE_DELAY_us	13

/** @brief Time (us) to hold the bus low to signal a zero write */
#define ONEWIRE_TIME_WRITE_0_us				100

/** @brief Time (us) to hold the bus low to signal a one write */
#define ONEWIRE_TIME_WRITE_1_us				2

/** @brief Sends a 1-wire reset command, returning the presence of any connected device(s) */
bool onewire_reset(struct ds18b20_single_drv_t * const drv);

/** @brief Writes a single byte on the 1-wire bus */
void onewire_write_byte(struct ds18b20_single_drv_t * const drv, const uint_fast8_t databyte, const enum onewire_drive_t drive);

/** @brief Reads a single byte from the 1-wire bus (requires a read command to be issued) */
uint_fast8_t onewire_read_byte(struct ds18b20_single_drv_t * const drv);

/** @brief Calculates the CRC checksum of len bytes using the 1-wire CRC model */
uint_fast8_t onewire_calccrc(uint_fast8_t * data, size_t len);

#endif /* ONEWIRE_H_ */