#include "ds18b20_single.h"
#include "onewire.h"

bool ds18b20_single_init(struct ds18b20_single_drv_t * const drv){
	bool retval = onewire_reset(drv);
	if(retval){
		uint_fast8_t configreg;
		switch(drv->bitdepth){
			case ds18b20_single_bitdepth_9bit:
				configreg = DS18B20_CONF_9BIT;
				break;
			case ds18b20_single_bitdepth_10bit:
				configreg = DS18B20_CONF_10BIT;
				break;
			case ds18b20_single_bitdepth_11bit:
				configreg = DS18B20_CONF_11BIT;
				break;
			default:	//Default to 12-bit resolution
			case ds18b20_single_bitdepth_12bit:
				configreg = DS18B20_CONF_12BIT;
				break;
		}
		
		//Write data bytes
		onewire_write_byte(drv, DS18B20_SKIP_ROM, onewire_drive_lowpwr);
		onewire_write_byte(drv, DS18B20_WRITE_PAD, onewire_drive_lowpwr);
		onewire_write_byte(drv, 0, onewire_drive_lowpwr);		//Write to the Th register
		onewire_write_byte(drv, 0, onewire_drive_lowpwr);		//Write to the Tl register
		onewire_write_byte(drv, configreg, onewire_drive_lowpwr);		//Write to the config register
		
		//Verify data bytes
		onewire_reset(drv);
		onewire_write_byte(drv, DS18B20_SKIP_ROM, onewire_drive_lowpwr);
		onewire_write_byte(drv, DS18B20_READ, onewire_drive_lowpwr);
		
		uint_fast8_t rawdata[DS18B20_NUM_DATA_BYTES];
		uint_fast8_t i;
		for(i = 0; i < sizeof(rawdata)/sizeof(rawdata[0]); i++){
			rawdata[i] = onewire_read_byte(drv);
		}
		uint_fast8_t crcval = onewire_calccrc(&rawdata[0], sizeof(rawdata)/sizeof(rawdata[0]));
		if(crcval != 0 || rawdata[4] != configreg){
			retval = false;
		}
	}
	return retval;
}

bool ds18b20_start_meas(struct ds18b20_single_drv_t * const drv){
	const bool presence = onewire_reset(drv);
	if(presence){
		onewire_write_byte(drv, DS18B20_SKIP_ROM, onewire_drive_lowpwr);
		onewire_write_byte(drv, DS18B20_COMM_CONV, onewire_drive_highpwr);
	}
	return presence;
}

bool ds18b20_get_meas(struct ds18b20_single_drv_t * const drv, int_fast16_t * const meastemp_raw){
	bool retval = false;
	const bool presence = onewire_reset(drv);
	if(presence){
		onewire_write_byte(drv, DS18B20_SKIP_ROM, onewire_drive_lowpwr);
		onewire_write_byte(drv, DS18B20_READ, onewire_drive_lowpwr);
		
		uint_fast8_t rawdata[DS18B20_NUM_DATA_BYTES];
		uint_fast8_t i;
		for(i = 0; i < sizeof(rawdata)/sizeof(rawdata[0]); i++){
			rawdata[i] = onewire_read_byte(drv);
		}
		uint_fast8_t crcval = onewire_calccrc(&rawdata[0], sizeof(rawdata)/sizeof(rawdata[0]));
		if(crcval == 0){
			*meastemp_raw = rawdata[0] | ((int_fast16_t)rawdata[1]) << 8;
			retval = true;
		}
	}
	return retval;
}