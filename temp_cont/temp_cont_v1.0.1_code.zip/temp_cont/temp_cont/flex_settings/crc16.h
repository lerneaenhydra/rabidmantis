/** @file Simple implementation of the CCITT-16 CRC algorithm.
 *
 * CRC algorithm based on the PYCRC generator (http://www.tty1.net/pycrc/index_en.html)
 *
 * Support for Texas Instruments C28x cores is added by using the __byte
 * intrinsic and assumes data is stored MSB-first (IE 0x01, 0x02, 0x03, 0x04 is
 * stored as 0x0102, 0x0304).
 *
 ******************************************************************************
 *
 * Copyright (c) 2006-2013, Thomas Pircher <tehpeh@gmx.net>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 ******************************************************************************
 *
 * Some test vectors for this generator (ASCII string inputs);
 * "helloworld"		-> 0x589C
 * "123456789"		-> 0x0A74
 * "testing1234"	-> 0xBEBC
 */
#ifndef CRC16_H_
#define CRC16_H_

#include <stdint.h>

/** @brief Returns the CRC of a given data block.
 * @param *data Pointer to start of data to pass
 * @param len Number of bytes to read
 * @return CRC value */
#ifdef __TMS320C2000__
uint_fast16_t crc16(uint_least8_t *data, uint_fast16_t bytes);
#else
uint_fast16_t crc16(uint8_t *data, uint_fast16_t bytes);
#endif

#endif /* CRC16_H_ */
