#include "crc16.h"
#include <stdbool.h>
#include <stddef.h>

 /* Generated on Thu Feb 12 10:25:11 2015,
 * by pycrc v0.8.1, http://www.tty1.net/pycrc/
 * using the configuration:
 *    Width        = 16
 *    Poly         = 0x755b
 *    XorIn        = 0xffff
 *    ReflectIn    = True
 *    XorOut       = 0x0000
 *    ReflectOut   = True
 *    Algorithm    = table-driven
 */
static const uint16_t crc_table[16] = {
    0x0000, 0xacac, 0xec05, 0x40a9, 0x6d57, 0xc1fb, 0x8152, 0x2dfe,
    0xdaae, 0x7602, 0x36ab, 0x9a07, 0xb7f9, 0x1b55, 0x5bfc, 0xf750
};

#ifdef __TMS320C2000__
#error Verify test vectors give valid output
uint16_t crc16(uint_fast8_t *data_p, uint_fast16_t bytes){
#else
uint_fast16_t crc16(uint8_t *data_p, uint_fast16_t bytes){
#endif
	uint_fast8_t i;
	uint16_t crc = 0xFFFF;

	if(bytes == 0 || data_p == NULL){
		return crc;
	}

	for(i = 0; i < bytes; i++){
		uint_fast8_t nextbyte;
#ifdef __TMS320C2000__
		nextbyte = __byte((int*)(data_p),((i) ^ 0x01)); /* XOR with bit 0 to access data MSB-first (IE. like a uint8_t*) */
#else
		nextbyte = data_p[i];
#endif
		uint_fast8_t tbl_idx = crc ^ (nextbyte >> (0 * 4));
		crc = crc_table[tbl_idx & 0x0F] ^ (crc >> 4);
		tbl_idx = crc ^ (nextbyte >> (1 * 4));
		crc = crc_table[tbl_idx & 0x0F] ^ (crc >> 4);
	}
	return crc & 0xFFFF;
}
