
#include "eeprom_redundant.h"
#include <stddef.h>
#include <string.h>
#include <limits.h>
#include "../globals.h"
#include "crc16.h"

#ifdef AVR_EEP_LIBC
#include <avr/eeprom.h>
#else
#include "../ext_perip/spi_eeprom.h"
#endif

#ifdef AVR_PRINT_DEBUG
#include <stdio.h>
#endif

#ifdef AVR_EEP_LIBC
/** @brief Compatbility function wrapper used to verify a block of EEPROM data matches some RAM data */
bool avr_eeprom_verify_block(uint_fast16_t src, uint_fast8_t src_local[], uint_fast16_t bytes){
	uint_fast16_t idx = 0;
	#ifdef AVR_PRINT_DEBUG
	printf_P(PSTR("Comparing %d bytes, at local offset %d, eeprom offset %d\n"), bytes, *src_local, src);
	#endif
	while(bytes--){
		uint_fast8_t mem = eeprom_read_byte((const uint8_t *)src + idx);
		if(mem != src_local[idx]){
			#ifdef AVR_PRINT_DEBUG 
			printf_P(PSTR("Mismatch with %d bytes remaining\n"), bytes);
			#endif
			return false;
		}
		idx++;
	}
	#ifdef AVR_PRINT_DEBUG
	printf_P(PSTR("Data was identical\n"));
	#endif
	return true;
}
#endif

/** @brief A single setting with a corresponding CRC checksum */
struct eeprom_redundant_setting_t{
	struct flex_setting_t setting;
	uint16_t crc;
};

bool eeprom_redundant_load(const uint_fast16_t eeprom_base_byte){
	uint_fast16_t i;	//The current setting we are looking at
	#ifdef AVR_PRINT_DEBUG
	printf_P(PSTR("eeprom load;\n"));
	#endif
	for(i = 0; i < FLEX_NUM_PARAM; i++){
		#ifdef AVR_PRINT_DEBUG
		printf_P(PSTR("setting %d, "), i);
		#endif

		uint_fast16_t copy;							//The current copy of the current setting (IE. the n'th redundant copy)
		//Temporary storage element of a single setting whose CRC check has passed
		struct eeprom_redundant_setting_t setting;
		//Note: It's critical that all bytes of setting are initially zero,
		//including padding bytes! (Otherwise the CRC checksum will be invalid)
		memset(&setting, 0, sizeof(setting));

		bool crcpass[EEPROM_REDUNDANT_LEVEL];		//Indicates the CRC-pass status of the copy'th setting
		uint16_t crc[EEPROM_REDUNDANT_LEVEL];		//Copy of CRC value for the copy'th setting
		bool crcpass_flag = false;					//True if at least one copy's CRC was valid
		bool crcfail_flag = false;					//True if at least one copy's CRC was invalid

		for(copy = 0; copy < EEPROM_REDUNDANT_LEVEL; copy++){
			#ifdef AVR_PRINT_DEBUG
			printf_P(PSTR("copy %d, "), copy);
			#endif
			struct eeprom_redundant_setting_t candidate_setting;
			//Note: It's critical that all bytes of setting are initially zero,
			//including padding bytes! (Otherwise the CRC checksum will be invalid)
			memset(&candidate_setting, 0, sizeof(candidate_setting));

			//Base address of data in EEPROM
			const uint_fast16_t addr = eeprom_base_byte + sizeof(candidate_setting) * (copy + i * EEPROM_REDUNDANT_LEVEL)*(CHAR_BIT/8);
			
			#ifdef AVR_PRINT_DEBUG
			printf_P(PSTR("eeprom address %d\n"), addr);
			#endif

			//Read data from EEPROM
#ifdef AVR_EEP_LIBC
			eeprom_read_block(&candidate_setting, (uint8_t *)addr, sizeof(candidate_setting)*(CHAR_BIT/8));
#else
#ifdef __TMS320C2000__
			spi_eeprom_read_block(&EEPROM_SPI_DRIVER, addr, (uint_fast8_t *) &candidate_setting, sizeof(candidate_setting)*(CHAR_BIT/8));
#else
			spi_eeprom_read_block(&EEPROM_SPI_DRIVER, addr, (uint8_t *) &candidate_setting, sizeof(candidate_setting)*(CHAR_BIT/8));
#endif
#endif

			//Compare stored CRC with calculated CRC
#ifdef __TMS320C2000__
			const uint16_t crc_calc = crc16((uint_fast8_t *)&candidate_setting.setting, sizeof(candidate_setting.setting)*(CHAR_BIT/8));
#else
			uint16_t crc_calc = crc16((uint8_t *)&candidate_setting.setting, sizeof(candidate_setting.setting)*(CHAR_BIT/8));
#endif
			if(crc_calc == candidate_setting.crc){
				#ifdef AVR_PRINT_DEBUG
				printf_P(PSTR("CRC pass with CRC %x\n"), crc_calc);
				#endif
				//Check if there are multiple copies with valid CRC, if so mark higher copies as invalid and copy the first copy to the duplicate
				int_fast8_t j = copy;
				bool crc_contradiction = false;
				while(--j >= 0){
					if(crc_calc != crc[j] && crcpass[j] == true){
						#ifdef AVR_PRINT_DEBUG
						printf_P(PSTR("CRC contradiction!\n"));
						#endif
						crcpass[copy] = false;
						crcfail_flag = true;
						crc_contradiction = true;
					}
				}

				if(!crc_contradiction){
					crcpass[copy] = true;
					crc[copy] = candidate_setting.crc;
					crcpass_flag = true;
					setting = candidate_setting;
				}
			}else{
				#ifdef AVR_PRINT_DEBUG
				printf_P(PSTR("CRC fail, calculated %x, read %x\n"), crc_calc, candidate_setting.crc);
				#endif
				crcfail_flag = true;
				crcpass[copy] = false;
			}
		}

		//If all copies of a setting were invalid, we're boned =(
		if(crcpass_flag == false){
			#ifdef AVR_PRINT_DEBUG
			printf_P(PSTR("All CRC fail\n"));
			#endif
			return false;
		}

		if(crcfail_flag){		//If there was some invalid data, replace it with a known-good copy
			#ifdef AVR_PRINT_DEBUG
			printf_P(PSTR("Some CRC fail; will copy good to bad sections\n"));
			#endif
			for(copy = 0; copy < EEPROM_REDUNDANT_LEVEL; copy++){
				if(crcpass[copy] == false){
#ifdef AVR_PRINT_DEBUG
					printf_P(PSTR("Copying to section %d\n"), copy);
#endif
					//Base address of data in EEPROM
					uint_fast16_t addr = eeprom_base_byte + sizeof(setting) * (copy + i * EEPROM_REDUNDANT_LEVEL) * (CHAR_BIT/8);
					//If the stored data is not identical, update the stored data...
#ifdef AVR_EEP_LIBC
					#ifdef AVR_PRINT_DEBUG
					printf_P(PSTR("Writing %d bytes at offset %d\n"), sizeof(setting)*(CHAR_BIT/8), addr);
					#endif
					eeprom_write_block((uint_fast8_t *) &setting, (uint8_t *)addr, sizeof(setting)*(CHAR_BIT/8));
#else
#ifdef __TMS320C2000__
					spi_eeprom_write_block(&EEPROM_SPI_DRIVER, addr, (uint_fast8_t *) &setting, sizeof(setting)*(CHAR_BIT/8));
#else
					spi_eeprom_write_block(&EEPROM_SPI_DRIVER, addr, (uint8_t *) &setting, sizeof(setting)*(CHAR_BIT/8));
#endif
#endif
					//...and verify the data was written correctly, otherwise abort
#ifdef AVR_EEP_LIBC
					if(!avr_eeprom_verify_block(addr, (uint_fast8_t *) &setting, sizeof(setting)*(CHAR_BIT/8))){
#else
#ifdef __TMS320C2000__
					if(!spi_eeprom_verify_block(&EEPROM_SPI_DRIVER, addr, (uint_fast8_t *) &setting, sizeof(setting)*(CHAR_BIT/8))){
#else
					if(!spi_eeprom_verify_block(&EEPROM_SPI_DRIVER, addr, (uint8_t *) &setting, sizeof(setting)*(CHAR_BIT/8))){
#endif
#endif
						#ifdef AVR_PRINT_DEBUG
						printf_P(PSTR("Didn't read back same content as was written! =(\n"));
						#endif
						return false;
					}
				}
			}
		}

		//Finally, copy the verified data to the final struct
		setting_set_title(i, setting.setting.title);
#ifdef PARAM_UNITS_EN
		setting_set_unit(i, setting.setting.unit);
#endif
		setting_set_type(i, setting.setting.flex_type);
		setting_set_nvtype(i, setting.setting.nv_type);
		switch(setting.setting.flex_type){
		case FLEX_TYPE_INTEGER:
			setting_set_perm(i, setting.setting.x.num.perm);

			setting_set_int(i, FLEX_PARAM_MAX, setting.setting.x.num.max.integer, FLEX_FORCE_SUDO);
			//Only attempt to load values for non-volatile type parameter
			if(setting_get_nvtype(i) == FLEX_NVTYPE_NONVOLATILE){
				setting_set_int(i, FLEX_PARAM_VAL, setting.setting.x.num.val.integer, FLEX_FORCE_SUDO);
			}
			setting_set_int(i, FLEX_PARAM_MIN, setting.setting.x.num.min.integer, FLEX_FORCE_SUDO);
			break;
		case FLEX_TYPE_REAL:
			setting_set_perm(i, setting.setting.x.num.perm);

			setting_set_real(i, FLEX_PARAM_MAX, setting.setting.x.num.max.real, FLEX_FORCE_SUDO);
			//Only attempt to load values for non-volatile type parameter
			if(setting_get_nvtype(i) == FLEX_NVTYPE_NONVOLATILE){
				setting_set_real(i, FLEX_PARAM_VAL, setting.setting.x.num.val.real, FLEX_FORCE_SUDO);
			}
			setting_set_real(i, FLEX_PARAM_MIN, setting.setting.x.num.min.real, FLEX_FORCE_SUDO);
			break;
		case FLEX_TYPE_STRING:
			setting_set_perm(i, setting.setting.x.str.perm);
			//Only attempt to load values for non-volatile type parameter
			if(setting_get_nvtype(i) == FLEX_NVTYPE_NONVOLATILE){
				setting_set_str(i, setting.setting.x.str.string, FLEX_FORCE_SUDO);
			}
			break;
		default:
			return false;	//Should really never occur; the read data was verified!
		}
	}
	return true;
}

bool eeprom_redundant_save(const uint_fast16_t eeprom_base_byte){
	uint_fast16_t i;
	#ifdef AVR_PRINT_DEBUG
	printf_P(PSTR("eeprom save\n"));
	#endif
	for(i = 0; i < FLEX_NUM_PARAM; i++){
		#ifdef AVR_PRINT_DEBUG
		printf_P(PSTR("param %d\n"), i);
		#endif
		//For each setting, copy current data to a temporary struct that we can access completely freely
		struct eeprom_redundant_setting_t setting_shdw;
		//Note: It's critical that all bytes of setting are initially zero,
		//including padding bytes! (Otherwise the CRC checksum will be invalid)
		memset(&setting_shdw, 0, sizeof(setting_shdw));

		enum flex_type_t type_shdw;
		type_shdw = setting_get_type(i);
		if(type_shdw >= FLEX_TYPE_NUM){
			return false;	//Bug out if data is completely invalid
		}
		//Copy universal data
		setting_shdw.setting.flex_type = type_shdw;
		strncpy(setting_shdw.setting.title, setting_get_title(i), FLEX_SETTINGS_TITLE_LEN);
		setting_shdw.setting.title[FLEX_SETTINGS_TITLE_LEN] = '\0';	//Ensure string is null-padded
#ifdef PARAM_UNITS_EN
		strncpy(setting_shdw.setting.unit, setting_get_unit(i), FLEX_SETTINGS_UNIT_LEN);
		setting_shdw.setting.unit[FLEX_SETTINGS_UNIT_LEN] = '\0';		//Ensure string is null-padded
#endif
		setting_shdw.setting.nv_type = setting_get_nvtype(i);
		switch(type_shdw){
		case FLEX_TYPE_INTEGER:
			//Only write value parameter if parameter type set to nonvolatile
			if(setting_get_nvtype(i) == FLEX_NVTYPE_NONVOLATILE){
				setting_shdw.setting.x.num.val.integer = setting_get_int(i, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
			}else{
				setting_shdw.setting.x.num.val.integer = 0;
			}
			setting_shdw.setting.x.num.max.integer = setting_get_int(i, FLEX_PARAM_MAX, FLEX_FORCE_SUDO);
			setting_shdw.setting.x.num.min.integer = setting_get_int(i, FLEX_PARAM_MIN, FLEX_FORCE_SUDO);
			setting_shdw.setting.x.num.perm = setting_get_perm(i);
			break;
		case FLEX_TYPE_REAL:
			//Only write value parameter if parameter type set to nonvolatile
			if(setting_get_nvtype(i) == FLEX_NVTYPE_NONVOLATILE){
				setting_shdw.setting.x.num.val.real = setting_get_real(i, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
			}else{
				setting_shdw.setting.x.num.val.real = 0.0f;
			}
			setting_shdw.setting.x.num.max.real = setting_get_real(i, FLEX_PARAM_MAX, FLEX_FORCE_SUDO);
			setting_shdw.setting.x.num.min.real = setting_get_real(i, FLEX_PARAM_MIN, FLEX_FORCE_SUDO);
			setting_shdw.setting.x.num.perm = setting_get_perm(i);
			break;
		case FLEX_TYPE_STRING:
			//Only write value parameter if parameter type set to nonvolatile
			if(setting_get_nvtype(i) == FLEX_NVTYPE_NONVOLATILE){
				setting_get_string(i, &setting_shdw.setting.x.str.string[0], FLEX_FORCE_SUDO);
			}else{
				setting_shdw.setting.x.str.string[0] = '\0';	//Write empty string if parameter is of volatile type
			}
			setting_shdw.setting.x.str.perm = setting_get_perm(i);
			break;
		default:
			break;	//Should never occur, as we just checked that type_shdw is something valid
		}

#ifdef __TMS320C2000__
		setting_shdw.crc = crc16((uint_fast8_t *) &setting_shdw, sizeof(setting_shdw.setting)*(CHAR_BIT/8));
#else
		setting_shdw.crc = crc16((uint8_t *) &setting_shdw, sizeof(setting_shdw.setting)*(CHAR_BIT/8));
#endif

		#ifdef AVR_PRINT_DEBUG
		printf_P(PSTR("reference CRC %x\n"), setting_shdw.crc);
		#endif

		//Now we've got a local copy of the i'th setting and its CRC; check if the stored data matches this
		uint_fast16_t copy;
		for(copy = 0; copy < EEPROM_REDUNDANT_LEVEL; copy++){
			//Base address of data in EEPROM
			uint_fast16_t addr = eeprom_base_byte + sizeof(setting_shdw) * (copy + i * EEPROM_REDUNDANT_LEVEL) * (CHAR_BIT/8);
			
			#ifdef AVR_PRINT_DEBUG
			printf_P(PSTR("Checking EEPROM copy %d at offset %d"), copy, addr);
			#endif
			
#ifdef AVR_EEP_LIBC
			if(!avr_eeprom_verify_block(addr, (uint_fast8_t *) &setting_shdw, sizeof(setting_shdw)*(CHAR_BIT/8))){
#else
#ifdef __TMS320C2000__
			if(!spi_eeprom_verify_block(&EEPROM_SPI_DRIVER, addr, (uint_fast8_t *) &setting_shdw, sizeof(setting_shdw)*(CHAR_BIT/8))){
#else
			if(!spi_eeprom_verify_block(&EEPROM_SPI_DRIVER, addr, (uint8_t *) &setting_shdw, sizeof(setting_shdw)*(CHAR_BIT/8))){
#endif
#endif
				//If the stored data is not identical, update the stored data...
				#ifdef AVR_PRINT_DEBUG
				printf_P(PSTR("Stored settings differ! Will update\n"));
				#endif
#ifdef AVR_EEP_LIBC
				eeprom_write_block((uint_fast8_t *) &setting_shdw, (uint8_t *)addr, sizeof(setting_shdw)*(CHAR_BIT/8));
#else
#ifdef __TMS320C2000__
				spi_eeprom_write_block(&EEPROM_SPI_DRIVER, addr, (uint_fast8_t *) &setting_shdw, sizeof(setting_shdw)*(CHAR_BIT/8));
#else
				spi_eeprom_write_block(&EEPROM_SPI_DRIVER, addr, (uint8_t *) &setting_shdw, sizeof(setting_shdw)*(CHAR_BIT/8));
#endif
#endif
				//...and verify the data was written correctly, otherwise abort
#ifdef AVR_EEP_LIBC
				if(!avr_eeprom_verify_block(addr, (uint_fast8_t *) &setting_shdw, sizeof(setting_shdw)*(CHAR_BIT/8))){
#else
#ifdef __TMS320C2000__
				if(!spi_eeprom_verify_block(&EEPROM_SPI_DRIVER, addr, (uint_fast8_t *) &setting_shdw, sizeof(setting_shdw)*(CHAR_BIT/8))){
#else
				if(!spi_eeprom_verify_block(&EEPROM_SPI_DRIVER, addr, (uint8_t *) &setting_shdw, sizeof(setting_shdw)*(CHAR_BIT/8))){
#endif
#endif
					#ifdef AVR_PRINT_DEBUG
					printf_P(PSTR("Tried to update, but stored data doesn't match what we wrote! =("));
					#endif
					return false;
				}
			}
		}
	}
	return true;
}
