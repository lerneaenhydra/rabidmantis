#include "enc_callbacks.h"
#include <stdio.h>
#include <avr/pgmspace.h>
#include <math.h>
#include "globals.h"
#include "systime/systime.h"
#include "flex_settings/flex_settings.h"
#include "flex_settings/eeprom_redundant.h"
#include "pwm/pwm.h"

void enc_callback_push_p(struct enc_menu_screen_t * const screen){
	//On a push event, restore the screen to transition to on button release if we've previously disabled it
	if(screen->release_screen == NULL && scr_temp_int.release_screen != NULL){
		screen->release_screen = scr_temp_int.release_screen;
		scr_temp_int.release_screen = NULL;
	}
}

void enc_callback_rot_p(struct enc_menu_screen_t * const screen, const bool cw){
	//On a rotate event, temporarily disable screen transition on button release
	if(screen->release_screen != NULL && scr_temp_int.release_screen == NULL){
		scr_temp_int.release_screen = screen->release_screen;
		screen->release_screen = NULL;
	}
	//Act on cw and increment/decrement the chosen parameter with a prescaler based on the current button status
	FLEX_INT_T incval_int = 1;		//Integer values always use a base increment/decrement value of 1
	float incval_real = 1.0f;		//Real values need a base increment value depending on some compile-time settings which we'll set later on
	int_least8_t real_round = 0;	//Accuracy to round off final value to

	if(!cw){
		incval_int *= -1;
		incval_real *= -1.0f;
	}
	if(rotary_enc_get_btnstate(&g_rot_enc)){
		incval_int *= ROT_ENC_PRESSED_SCALE;
		incval_real *= ROT_ENC_PRESSED_SCALE;
	}

	FLEX_IDX_T param_idx;
	bool update_param = false;
	if(screen == &scr_tlo_p){
		real_round = PARAM_TEMP_ENC_RND;
		incval_real *= PARAM_TEMP_ENC_SCALE;
		param_idx = PARAM_TLO_IDX;
		update_param = true;
	}else if(screen == &scr_thi_p){
		real_round = PARAM_TEMP_ENC_RND;
		param_idx = PARAM_THI_IDX;
		incval_real *= PARAM_TEMP_ENC_SCALE;
		update_param = true;
	}else if(screen == &scr_thy_p){
		real_round = PARAM_TEMP_ENC_RND;
		param_idx = PARAM_THY_IDX;
		incval_real *= PARAM_TEMP_ENC_SCALE;
		update_param = true;
	}else if(screen == &scr_plo_p){
		real_round = PARAM_PWR_ENC_RND;
		param_idx = PARAM_PLO_IDX;
		incval_real *= PARAM_PWR_ENC_SCALE;
		update_param = true;
	}else if(screen == &scr_phi_p){
		real_round = PARAM_PWR_ENC_RND;
		param_idx = PARAM_PHI_IDX;
		incval_real *= PARAM_PWR_ENC_SCALE;
		update_param = true;
	}else if(screen == &scr_pct_p){
		real_round = PARAM_PWR_ENC_RND;
		param_idx = PARAM_PCT_IDX;
		incval_real *= PARAM_PWR_ENC_SCALE;
		update_param = true;
	}else if(screen == &scr_elo_p){
		real_round = PARAM_TEMP_ENC_RND;
		incval_real *= PARAM_TEMP_ENC_SCALE;
		param_idx = PARAM_ELO_IDX;
		update_param = true;
	}else if(screen == &scr_ehi_p){
		real_round = PARAM_TEMP_ENC_RND;
		incval_real *= PARAM_TEMP_ENC_SCALE;
		param_idx = PARAM_EHI_IDX;
		update_param = true;
	}else if(screen == &scr_sdl_p){
		param_idx = PARAM_SDL_IDX;
		//Scale SDL parameter based on a base value and the current SDL value
		incval_real *= PARAM_TIME_ENC_SCALE_s;
		const float curr_sdl = setting_get_real(param_idx, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
		//Add a crude 10-log scaling function
		if(curr_sdl > 100){
			incval_real *= 100;
			real_round = 1;
		}else if(curr_sdl > 10){
			incval_real *= 10;
			real_round = 10;
		}else{
			real_round = 100;
		}
		update_param = true;
	}else{
		//Screen is currently in some state that doesn't have a parameter to change
	}
	if(update_param){
		//Update parameter and display
		switch(setting_get_type(param_idx)){
			case FLEX_TYPE_REAL:
			{
				//Round real values off to a base accuracy to handle cumulative errors
				const float currval = setting_get_real(param_idx, FLEX_PARAM_VAL, FLEX_FORCE_SUDO);
				float finalval = currval + incval_real;
				finalval = (round(finalval * real_round)) / real_round;
				setting_set_real(param_idx, FLEX_PARAM_VAL, finalval, FLEX_FORCE_SUDO);
				printf_P(PSTR("Changing parameter %s to value %f\n"), setting_get_title(param_idx), setting_get_real(param_idx, FLEX_PARAM_VAL, FLEX_FORCE_NORMAL));
			}
				break;
			case FLEX_TYPE_INTEGER:
				setting_increment_int(param_idx, FLEX_PARAM_VAL, incval_int, FLEX_FORCE_NORMAL);
				printf_P(PSTR("Changing parameter %s to value %d\n"), setting_get_title(param_idx), setting_get_int(param_idx, FLEX_PARAM_VAL, FLEX_FORCE_NORMAL));
				break;
			default:
				//Should never occur
				break;
		}
		enc_callback_enter_p(screen);
		volatile float g_sdl_ref_shdw = S2US(setting_get_real(PARAM_SDL_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO));	//Apply the stored SDL value (that we may have just changed)
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
			//Apply stored SDL parameter
			g_sdl_ref = g_sdl_ref_shdw;
		}
	}
}

void enc_callback_save_p(struct enc_menu_screen_t * const screen){
	(void) screen;	//Suppress unused parameter warning
	eeprom_redundant_save(0);
	printf_P(PSTR("Settings saved to EEPROM with values;\n"));
	printf_P(PSTR("PARAM|         VALUE|       MINIMUM|       MAXIMUM\n"));
	FLEX_IDX_T i;
	for(i = 0; i < FLEX_NUM_PARAM; i++){
		printf_P(PSTR("%5s|"), setting_get_title(i));
		switch(setting_get_type(i)){
			case FLEX_TYPE_INTEGER:
				printf_P(PSTR("%14d|%14d|%14d\n"), setting_get_int(i, FLEX_PARAM_VAL, FLEX_FORCE_NORMAL), setting_get_int(i, FLEX_PARAM_MIN, FLEX_FORCE_NORMAL), setting_get_int(i, FLEX_PARAM_MAX, FLEX_FORCE_NORMAL));
				break;
			case FLEX_TYPE_REAL:
				printf_P(PSTR("%14g|%14g|%14g\n"), setting_get_real(i, FLEX_PARAM_VAL, FLEX_FORCE_NORMAL), setting_get_real(i, FLEX_PARAM_MIN, FLEX_FORCE_NORMAL), setting_get_real(i, FLEX_PARAM_MAX, FLEX_FORCE_NORMAL));
				break;
			default:
				printf_P(PSTR("Unknown variable type!\n"));
				break;
		}
	}
}

void enc_callback_enter_p(struct enc_menu_screen_t * const screen){
	FLEX_IDX_T param_idx;
	bool valid_param = false;
	if(screen == &scr_tlo_p){
		param_idx = PARAM_TLO_IDX;
		valid_param = true;
	}else if(screen == &scr_thi_p){
		param_idx = PARAM_THI_IDX;
		valid_param = true;
	}else if(screen == &scr_thy_p){
		param_idx = PARAM_THY_IDX;
		valid_param = true;
	}else if(screen == &scr_plo_p){
		param_idx = PARAM_PLO_IDX;
		valid_param = true;
	}else if(screen == &scr_phi_p){
		param_idx = PARAM_PHI_IDX;
		valid_param = true;
	}else if(screen == &scr_pct_p){
		param_idx = PARAM_PCT_IDX;
		valid_param = true;
	}else if(screen == &scr_elo_p){
		param_idx = PARAM_ELO_IDX;
		valid_param = true;
	}else if(screen == &scr_ehi_p){
		param_idx = PARAM_EHI_IDX;
		valid_param = true;
	}else if(screen == &scr_sdl_p){
		param_idx = PARAM_SDL_IDX;
		valid_param = true;
	}else{
		//Screen is currently in some state that doesn't have a parameter to change
	}
	if(valid_param){
		switch(setting_get_type(param_idx)){
			case FLEX_TYPE_INTEGER:
				fprintf_P(&seg_str, PSTR(DISPLINE("%3d")), setting_get_int(param_idx, FLEX_PARAM_VAL, FLEX_FORCE_NORMAL));
				break;
			case FLEX_TYPE_REAL:
				fprintf_P(&seg_str, PSTR(DISPLINE("%.3f")), setting_get_real(param_idx, FLEX_PARAM_VAL, FLEX_FORCE_NORMAL));
				break;
			default:
				//Should never occur
				break;
		}
	}
}

void enc_callback_tct_idle(struct enc_menu_screen_t * const screen){
	(void) screen;	//Suppress unused parameter warning
	static systime_t delay = 0;
	if(systime_get_delay_passed(delay)){
		delay = systime_get_delay(MS2US(DISP_TCT_PER_ms));
		if(main_get_temp_valid()){
			fprintf_P(&seg_str, PSTR("\r%f\n"), setting_get_real(PARAM_TCT_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO));
		}else{
			fprintf_P(&seg_str, PSTR("\r---\n"), setting_get_real(PARAM_TCT_IDX, FLEX_PARAM_VAL, FLEX_FORCE_SUDO));
		}
	}
}