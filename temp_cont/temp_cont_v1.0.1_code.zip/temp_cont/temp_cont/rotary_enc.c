#include "rotary_enc.h"
#include <stdlib.h>

static bool rotary_enc_check_valid(struct rotary_enc_t * const encstate){
	if(encstate->enc_btn_callback == NULL ||
		encstate->enc_get_btnstate == NULL ||
		encstate->enc_get_rotstate == NULL ||
		encstate->enc_rot_callback == NULL){
		return false;
	}else{
		return true;
	}
}

void rotary_enc_idle(struct rotary_enc_t * const encstate){
	if(!rotary_enc_check_valid(encstate)){
		return;
	}
	bool new_a, new_b;
	encstate->enc_get_rotstate(&new_a, &new_b);
	switch(encstate->enc_pos){
		//enc_pos records the last A,B state
		case 0:	//We had state 0,0
			if(new_a && !new_b){
				//Moving to state 1,0
				encstate->enc_pos = 2;
				if(encstate->last_dir_cw){
					//Motion was debounced, signal as CW a rotation event
					encstate->curr_enc_step++;
					if(encstate->curr_enc_step >= encstate->enc_divisor){
						encstate->curr_enc_step = 0;
						encstate->enc_rot_callback(true);
					}
				}else{
					encstate->curr_enc_step = encstate->enc_divisor;
				}
				//This was CW motion, so set the CW bit
				encstate->last_dir_cw = true;
			}else if(!new_a && new_b){
				//Moving to state 0,1
				encstate->enc_pos = 1;
				if(!encstate->last_dir_cw){
					//Motion was debounced, signal as CCW a rotation event
					encstate->curr_enc_step++;
					if(encstate->curr_enc_step >= encstate->enc_divisor){
						encstate->curr_enc_step = 0;
						encstate->enc_rot_callback(false);
					}
				}else{
					encstate->curr_enc_step = encstate->enc_divisor;
				}
				//This was CCW motion, so clear the CW bit
				encstate->last_dir_cw = false;
			}
			break;
		case 1:	//We had state 0,1
			if(new_a && new_b){
				//Moving to state 1,1
				encstate->enc_pos = 3;
				if(!encstate->last_dir_cw){
					//Motion was debounced, signal as CCW a rotation event
					encstate->curr_enc_step++;
					if(encstate->curr_enc_step >= encstate->enc_divisor){
						encstate->curr_enc_step = 0;
						encstate->enc_rot_callback(false);
					}
				}else{
					encstate->curr_enc_step = encstate->enc_divisor;
				}
				//This was CCW motion, so clear the CW bit
				encstate->last_dir_cw = false;
			}else if(!new_a && !new_b){
				//Moving to state 0,0
				encstate->enc_pos = 0;
				if(encstate->last_dir_cw){
					//Motion was debounced, signal as CW a rotation event
					encstate->curr_enc_step++;
					if(encstate->curr_enc_step >= encstate->enc_divisor){
						encstate->curr_enc_step = 0;
						encstate->enc_rot_callback(true);
					}
				}else{
					encstate->curr_enc_step = encstate->enc_divisor;
				}
				//This was CW motion, so set the CW bit
				encstate->last_dir_cw = true;
			}
			break;
		case 2: //We had state 1,0
			if(new_a && new_b){
				//Moving to state 1,1
				encstate->enc_pos = 3;
				if(encstate->last_dir_cw){
					//Motion was debounced, signal as CW a rotation event
					encstate->curr_enc_step++;
					if(encstate->curr_enc_step >= encstate->enc_divisor){
						encstate->curr_enc_step = 0;
						encstate->enc_rot_callback(true);
					}
				}else{
					encstate->curr_enc_step = encstate->enc_divisor;
				}
				//This was CW motion, so set the CW bit
				encstate->last_dir_cw = true;
			}else if(!new_a && !new_b){
				//Moving to state 0,0
				encstate->enc_pos = 0;
				if(!encstate->last_dir_cw){
					//Motion was debounced, signal as CCW a rotation event
					encstate->curr_enc_step++;
					if(encstate->curr_enc_step >= encstate->enc_divisor){
						encstate->curr_enc_step = 0;
						encstate->enc_rot_callback(false);
					}
				}else{
					encstate->curr_enc_step = encstate->enc_divisor;
				}
				//This was CCW motion, so clear the CW bit
				encstate->last_dir_cw = false;
			}
			break;
		case 3: //We had state 1,1
			if(new_a && !new_b){
				//Moving to state 1,0
				encstate->enc_pos = 2;
				if(!encstate->last_dir_cw){
					//Motion was debounced, signal as CCW a rotation event
					encstate->curr_enc_step++;
					if(encstate->curr_enc_step >= encstate->enc_divisor){
						encstate->curr_enc_step = 0;
						encstate->enc_rot_callback(false);
					}
				}else{
					encstate->curr_enc_step = encstate->enc_divisor;
				}
				//This was CCW motion, so clear the CW bit
				encstate->last_dir_cw = false;
			}else if(!new_a && new_b){
				//Moving to state 0,1
				encstate->enc_pos = 1;
				if(encstate->last_dir_cw){
					//Motion was debounced, signal as CW a rotation event
					encstate->curr_enc_step++;
					if(encstate->curr_enc_step >= encstate->enc_divisor){
						encstate->curr_enc_step = 0;
						encstate->enc_rot_callback(true);
					}
				}else{
					encstate->curr_enc_step = encstate->enc_divisor;
				}
				//This was CW motion, so set the CW bit
				encstate->last_dir_cw = true;
			}
			break;
	}
	if(encstate->enc_get_btnstate()){
		//Raw button state is depressed
		if(encstate->btn_state < encstate->btn_bounce_int_thrs){
			//If we're not saturated, increment the integrator count
			encstate->btn_state++;
			//If we just saturated now, call the depressed callback
			if(encstate->btn_state >= encstate->btn_bounce_int_thrs && encstate->btn_state_debounced == false){
				encstate->enc_btn_callback(true);
				encstate->btn_state_debounced = true;
			}
		}
	}else{
		//Similar to above, decrement and call callback if zero
		if(encstate->btn_state != 0){
			encstate->btn_state--;
			if(encstate->btn_state == 0 && encstate->btn_state_debounced == true){
				encstate->enc_btn_callback(false);
				encstate->btn_state_debounced = false;
			}
		}
	}	
}

bool rotary_enc_get_btnstate(struct rotary_enc_t * const encstate){
	if(!rotary_enc_check_valid(encstate)){
		return false;
	}
	return encstate->btn_state_debounced;
}

void rotary_enc_init(struct rotary_enc_t * const encstate){
	if(!rotary_enc_check_valid(encstate)){
		return;
	}
	//Set internal encoder position to the current raw position
	bool a, b;
	encstate->enc_get_rotstate(&a, &b);
	encstate->enc_pos = a | (b <<1);
	encstate->curr_enc_step = 0;
	
	//Set internal button state to the current raw level
	const bool raw_btnstate = encstate->enc_get_btnstate();
	if(raw_btnstate){
		encstate->btn_state = encstate->btn_bounce_int_thrs;
		encstate->btn_state_debounced = true;
	}else{
		encstate->btn_state = 0;
		encstate->btn_state_debounced = false;
	}
}
