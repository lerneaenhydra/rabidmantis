#include "board.h"
#include <avr/io.h>
#include <util/atomic.h>
#include <stdlib.h>
#include "baud_calc.h"
#include "config.h"
#include "systime/systime.h"
#include "ccpwite.h"

#define USARTPORT		PORTC
#define USARTRXPINCFG	PIN2CTRL
#define USARTTXPIN		PIN3_bm
#define USARTREG		USARTC0

#define SWPORT			PORTA
#define SWOUTPIN		PIN1_bm
#define OKOUTPIN		PIN3_bm
#define NOKOUTPIN		PIN4_bm
#define SWFBPIN			PIN2_bm
#define SWFBPINCFG		PIN2CTRL

#define ENCPORT			PORTC
#define ENCAPIN			PIN6_bm
#define ENCAPINCFG		PIN6CTRL
#define ENCBPIN			PIN5_bm
#define ENCBTNPIN		PIN7_bm

#define DISPCOM0PORT	PORTC
#define DISPCOM0PIN		PIN0_bm
#define DISPCOM0PINCFG	PIN0CTRL
#define DISPCOM1PORT	PORTA
#define DISPCOM1PIN		PIN6_bm
#define DISPCOM1PINCFG	PIN6CTRL
#define DISPCOM2PORT	PORTA
#define DISPCOM2PIN		PIN7_bm
#define DISPCOM2PINCFG	PIN7CTRL

#define TS_PORT			PORTA
#define TS_PIN			PIN5_bm
#define TS_PINCFG		PIN5CTRL

#define DISPSEGPORT		PORTD

#define SYSTIME_TIMER TCC4

#define DISP_TIMER TCC5

void board_en_pmic_all(void){
	PMIC.CTRL |= PMIC_HILVLEN_bm | PMIC_MEDLVLEN_bm | PMIC_LOLVLEN_bm;
}

void board_ts_drive_high(const bool out_en){
	if(out_en){
		//Set as totem-pole output and drive high
		TS_PORT.TS_PINCFG = PORT_OPC_TOTEM_gc;
		TS_PORT.OUTSET = TS_PIN;
	}else{
		//Set as input and enable open-drain drive
		TS_PORT.TS_PINCFG = PORT_OPC_WIREDAND_gc;
		TS_PORT.OUTSET = TS_PIN;
	}
}

void board_ts_write_state(const bool state){
	TS_PORT.TS_PINCFG = PORT_OPC_WIREDAND_gc;	//Restore pin output drive type
	if(state){
		//Want to drive a passive state (pullup)
		TS_PORT.OUTSET = TS_PIN;
	}else{
		//Want to drive a low state (sink current)
		TS_PORT.OUTCLR = TS_PIN;
	}
}

bool board_ts_get_state(void){
	if(TS_PORT.IN & TS_PIN){
		return true;
	}else{
		return false;
	}
}

void board_init_io(void){
	//Set up all IO pins
	//Set up temperature probe I/O
	board_ts_drive_high(false);	//For now, don't drive high power to temp sense
	TS_PORT.DIRSET = TS_PIN;
	
	//Set up UART pin. In this case we only want/need the Tx output, so disable the Rx input buffer and apply a pullup resistor
	USARTPORT.OUTCLR = USARTTXPIN;
	USARTPORT.DIRSET = USARTTXPIN;
	USARTPORT.USARTRXPINCFG = PORT_ISC_INPUT_DISABLE_gc | PORT_OPC_PULLUP_gc;
	
	//Set up IO used for power switch
	SWPORT.OUTCLR = SWOUTPIN | OKOUTPIN | NOKOUTPIN;
	SWPORT.SWFBPINCFG = PORT_OPC_PULLUP_gc;
	SWPORT.DIRSET = SWOUTPIN | OKOUTPIN | NOKOUTPIN;
	
	//Set up encoder and button as input with pull-up
	PORTCFG.MPCMASK = ENCAPIN | ENCBPIN | ENCBTNPIN;
	ENCPORT.ENCAPINCFG = PORT_OPC_PULLUP_gc;
	
	//Set up 7-segment display. 
	//Set up the display-selecting pins, set all to open-collector output where a zero bit in the OUT register implies an active transistor
	DISPCOM0PORT.OUTSET = DISPCOM0PIN;
	DISPCOM1PORT.OUTSET = DISPCOM1PIN;
	DISPCOM2PORT.OUTSET = DISPCOM2PIN;
	DISPCOM0PORT.DISPCOM0PINCFG = PORT_OPC_WIREDAND_gc;
	DISPCOM1PORT.DISPCOM1PINCFG = PORT_OPC_WIREDAND_gc;
	DISPCOM2PORT.DISPCOM2PINCFG = PORT_OPC_WIREDAND_gc;
	DISPCOM0PORT.DIRSET = DISPCOM0PIN;
	DISPCOM1PORT.DIRSET = DISPCOM1PIN;
	DISPCOM2PORT.DIRSET = DISPCOM2PIN;
	
	//Set up the segment pins
	//Set up the segment-selecting pins, set all to open-emitter output where a one bit in the OUT register implies an active transistor
	DISPSEGPORT.OUTCLR = 0xFF;
	PORTCFG.MPCMASK = 0xFF;
	DISPSEGPORT.PIN0CTRL = PORT_OPC_WIREDOR_gc;
	DISPSEGPORT.DIRSET = 0xFF;
	
}

bool board_get_error_reset(void){
	bool retval = false;
	if(RST.STATUS & (RST_WDRF_bm | RST_BORF_bm)){
		retval = true;
	}
	return retval;
}

void board_init_timer(void){
	//Hack-y initialization as datasheet seems to be incorrect (?)
	//We're setting up for triggering OVFINT, we're using the CCA ISR...
	//Based on http://www.avrfreaks.net/index.php?name=PNphpBB2&file=viewtopic&p=1066160
	
	//Set up systime timer
	SYSTIME_TIMER.CTRLB |= TC45_WGMODE_NORMAL_gc;
	SYSTIME_TIMER.INTCTRLB |= TC45_CCAINTLVL_MED_gc;
	SYSTIME_TIMER.PER = (F_CPU * SYSTIME_PERIOD_us)/(1000000ULL);
	SYSTIME_TIMER.CTRLA |= TC45_CLKSEL_DIV1_gc;
	
	//Set up display timer
	DISP_TIMER.CTRLB |= TC45_WGMODE_NORMAL_gc;
	DISP_TIMER.INTCTRLB |= TC45_CCAINTLVL_HI_gc;
	DISP_TIMER.PER = (F_CPU * DISP_PER_us)/(1000000ULL);
	DISP_TIMER.CTRLA |= TC45_CLKSEL_DIV1_gc;
}

void board_init_clk(void){
	//Switch to 32MHz source, disable 2Mhz source, use DFLL for increase clock accuracy
	OSC.CTRL |= OSC_RC32MEN_bm | OSC_RC32KEN_bm;
	while(!(OSC.STATUS & OSC_RC32KRDY_bm));
	while(!(OSC.STATUS & OSC_RC32MRDY_bm));
	DFLLRC32M.CTRL = DFLL_ENABLE_bm ;
	CCPWrite(&CLK.CTRL, CLK_SCLKSEL_RC32M_gc);	//CLK.CTRL is CCP-protected
	OSC.CTRL &= ~OSC_RC2MEN_bm;
}

void board_uart_init(void){
	USARTREG.CTRLA = 0;
	USARTREG.CTRLB = USART_TXEN_bm;
	USARTREG.CTRLC = USART_CMODE_ASYNCHRONOUS_gc | USART_CHSIZE_8BIT_gc;
	
	USARTREG.BAUDCTRLA = BSEL(F_CPU, BOARD_UART_BAUD) & 0xFF;
	USARTREG.BAUDCTRLB = (BSCALE(F_CPU, BOARD_UART_BAUD) << USART_BSCALE_gp) | ((BSEL(F_CPU, BOARD_UART_BAUD) >> 8) & USART_BSEL_gm);
}

void boart_uart_putc(char data){
	while(!(USARTREG.STATUS & USART_DREIF_bm)){};	//Wait until UART module ready to receive data
	USARTREG.DATA = data;
}

void board_get_enc(bool * const a, bool * const b){
	if(a == NULL || b == NULL){
		return;
	}
	if(ENCPORT.IN & ENCAPIN){
		*a = true;
	}else{
		*a = false;
	}
	if(ENCPORT.IN & ENCBPIN){
		*b = true;
	}else{
		*b = false;
	}
}

bool board_get_encbtn(void){
	if(ENCPORT.IN & ENCBTNPIN){
		return false;
	}else{
		return true;
	}
}

void board_set_output(const bool output_en){
	if(output_en){
		SWPORT.OUTSET = SWOUTPIN;
	}else{
		SWPORT.OUTCLR = SWOUTPIN;
	}
}

void board_set_errstate(const bool errstate){
	if(errstate){
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
			SWPORT.OUTSET = NOKOUTPIN;
			SWPORT.OUTCLR = OKOUTPIN;	
		}
	}else{
		ATOMIC_BLOCK(ATOMIC_RESTORESTATE){
			SWPORT.OUTSET = OKOUTPIN;
			SWPORT.OUTCLR = NOKOUTPIN;
		}
	}
}

bool board_get_swerr(void){
	if(SWPORT.IN & SWFBPIN){
		return true;	
	}else{
		return false;
	}
}

void board_set_seven_seg(const seven_seg_num_disp_t n, const uint_least8_t seg_raw){
	//First, disable all output
	DISPSEGPORT.OUTCLR = 0xFF;
	
	//Now, select the correct display
	switch(n){
		case 0:
			DISPCOM0PORT.OUTCLR = DISPCOM0PIN;
			DISPCOM1PORT.OUTSET = DISPCOM1PIN;
			DISPCOM2PORT.OUTSET = DISPCOM2PIN;
			break;
		case 1:
			DISPCOM0PORT.OUTSET = DISPCOM0PIN;
			DISPCOM1PORT.OUTCLR = DISPCOM1PIN;
			DISPCOM2PORT.OUTSET = DISPCOM2PIN;
			break;
		case 2:
			DISPCOM0PORT.OUTSET = DISPCOM0PIN;
			DISPCOM1PORT.OUTSET = DISPCOM1PIN;
			DISPCOM2PORT.OUTCLR = DISPCOM2PIN;
			break;
	}
	
	//Now, drive the correct segments
	DISPSEGPORT.OUT = seg_raw;
}