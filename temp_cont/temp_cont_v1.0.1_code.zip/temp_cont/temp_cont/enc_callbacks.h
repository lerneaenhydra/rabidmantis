/** @file Contains all callback functions for the enc_menu subsystem */ 


#ifndef ENC_CALLBACKS_H_
#define ENC_CALLBACKS_H_

#include "enc_menu/enc_menu.h"

/** @brief Callback function on leaving parameter screen. Saves settings to EEPROM and lists all parameters over UART. */
void enc_callback_save_p(struct enc_menu_screen_t * const screen);

/** @brief General callback function for parameter screens on enter, displays the current parameter's value */
void enc_callback_enter_p(struct enc_menu_screen_t * const screen);

/** @brief General callback function for parameter screens on push, restores the link screen on release event */
void enc_callback_push_p(struct enc_menu_screen_t * const screen);

/** @brief General callback function for parameter screens on rotation, updates the relevant parameter and updates the display */
void enc_callback_rot_p(struct enc_menu_screen_t * const screen, const bool cw);

/** @brief Idle callback function for displaying current temperature */
void enc_callback_tct_idle(struct enc_menu_screen_t * const screen);

#endif /* ENC_CALLBACKS_H_ */