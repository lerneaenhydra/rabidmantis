/** @file ALl global variables */ 


#ifndef GLOBALS_H_
#define GLOBALS_H_

#include <stdio.h>
#include "config.h"
#include "board.h"
#include "temp_cont.h"
#include "enc_menu/enc_menu.h"
#include "rotary_enc.h"
#include "ds18b20_single/ds18b20_single.h"
#include "systime/systime.h"

//Temperature sensor driver
extern struct ds18b20_single_drv_t probe_drv;

//PWM output driver
extern struct pwm_t g_pwm;

//PWM switch delay time
extern systime_t g_sdl_ref;

//7-segment display setup
extern char g_disp_char_buf[2*DISP_NUMSEG];
extern uint_least8_t g_disp_frame_buf[DISP_NUMSEG];
extern struct seven_seg_driver_t g_disp;

//Stream setup
extern FILE seg_str;
extern FILE uart_str;

//Rotary encoder driver
extern struct rotary_enc_t g_rot_enc;

//Menu setup
//Current measured temperature screen
extern struct enc_menu_screen_t scr_tct;
extern struct enc_menu_screen_t scr_tct_p;
//Title low temp. screen
extern struct enc_menu_screen_t scr_tlo;
extern struct enc_menu_screen_t scr_tlo_p;
//Title high temp. screen
extern struct enc_menu_screen_t scr_thi;
extern struct enc_menu_screen_t scr_thi_p;
//Title hysteresis temp. screen
extern struct enc_menu_screen_t scr_thy;
extern struct enc_menu_screen_t scr_thy_p;
//Title low power screen
extern struct enc_menu_screen_t scr_plo;
extern struct enc_menu_screen_t scr_plo_p;
//Title high power screen
extern struct enc_menu_screen_t scr_phi;
extern struct enc_menu_screen_t scr_phi_p;
//Title cutoff power screen
extern struct enc_menu_screen_t scr_pct;
extern struct enc_menu_screen_t scr_pct_p;
//Title low temp error screen
extern struct enc_menu_screen_t scr_elo;
extern struct enc_menu_screen_t scr_elo_p;
//Title high temp error screen
extern struct enc_menu_screen_t scr_ehi;
extern struct enc_menu_screen_t scr_ehi_p;
//Title maximum switch period screen
extern struct enc_menu_screen_t scr_sdl;
extern struct enc_menu_screen_t scr_sdl_p;
//Internal screen used only for temporary variable storage
extern struct enc_menu_screen_t scr_temp_int;

extern struct enc_menu_master_t g_menu;

#endif /* GLOBALS_H_ */