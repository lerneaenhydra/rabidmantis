/* Software-defined sigma-delta PWM output library. This library drives
 * any number of arbitrary I/O pins to a set duty cycle. This is done with
 * a first-order sigma delta modulation scheme */

#ifndef PWM_H_
#define PWM_H_
#include <stdint.h>
#include <stdbool.h>

/** @brief Define to use the AVR-libc ATOMIC funcions*/
#define AVR_PWM_LIBC

#ifdef AVR_PWM_LIBC
#include <util/atomic.h>
#define PWM_ATOMIC(x_)	ATOMIC_BLOCK(ATOMIC_RESTORESTATE){x_;}
#else
#error	PWM.h needs some ATOMIC macro!
#endif

/**
 * @brief Sets the effective PWM bit resolution.
 * Valid values are 8 or 16 bits. For lightweight systems 8-bit accuracy
 * improves performance.
 */
#define PWM_RES_8BIT
//#define PWM_RES_16BIT

#if defined(PWM_RES_8BIT) && defined(PWM_RES_16BIT)
#error Either 8-bit or 16-bit resolution must be specified, not both!
#endif

#if !defined(PWM_RES_8BIT) && !defined(PWM_RES_16BIT)
#error One of 8-bit or 16-bit resolution must be specified!
#endif

#ifdef PWM_RES_8BIT
#define PWM_RES_MAXVAL	UINT8_MAX
typedef uint8_t pwm_int_ref_t;
typedef int16_t pwm_int_err_t;
#endif
#ifdef PWM_RES_16BIT
#define PWM_RES_MAXVAL	UINT16_MAX
typedef uint16_t pwm_int_ref_t;
typedef int32_t pwm_int_err_t;
#endif

/** @brief Converts a normalized duty cycle (0 - 1) to a value that can be used by pwm_set_duty */
#define PWM_FLT2DUTY(x)		((x) < 0 ? 0 : ((x) > 1 ? 1 : ((x) * PWM_RES_MAXVAL)))

/** @brief A single PWM driver structure. Initialize all fields to zero except function pointer */
struct pwm_t {
	pwm_int_ref_t	pwm_ref_duty;			//!<- The reference output duty cycle
	pwm_int_err_t	pwm_int_err;			//!<- The integrated error
	
	bool state_shdw;						//!<- Shadow variable of current output state
	void (*const pwm_set_raw)(bool state);	//!<- Function pointer to function to set raw GPIO pin state to a level set by state
};

/** @brief Initializes a single PWM driver */
void pwm_init(struct pwm_t * const drv);

/** @brief Updates a specific output channel to a new PWM value.
 * @param drv The driver to use.
 * @param pwm_val the new duty cycle to apply. Must be a value in the range of pwm_int_t
 */
void pwm_set_duty(struct pwm_t * const drv, pwm_int_ref_t set_pwm_val);

/** @brief Idle function to call periodically. The call rate is directly
 * proportional to the maximum output frequency.
 * @param drv The driver to use. */
void pwm_idle(struct pwm_t * const drv);

#endif /* PWM_H_ */