#include "globals.h"
#include <stdlib.h>
#include "util.h"
#include "nv_settings_setup.h"
#include "enc_callbacks.h"
#include "flex_settings/flex_settings.h"
#include "pwm/pwm.h"

//Temperature sensor driver
struct ds18b20_single_drv_t probe_drv = {
	.hp_drive = board_ts_drive_high,
	.lp_drive = board_ts_write_state,
	.get_bus = board_ts_get_state,
	.bitdepth = ds18b20_single_bitdepth_12bit
};

//PWM driver
struct pwm_t g_pwm = {
	.pwm_int_err = 0,
	.pwm_ref_duty = 0,
	.state_shdw = false,
	.pwm_set_raw = board_set_output
};

systime_t g_sdl_ref = 0;

//7-segment display setup
char g_disp_char_buf[2*DISP_NUMSEG];
uint_least8_t g_disp_frame_buf[DISP_NUMSEG];
struct seven_seg_driver_t g_disp = {
	.char_buf_len = numel(g_disp_char_buf),
	.char_buf = g_disp_char_buf,
	.char_cnt = 0,
	.curr_disp = 0,
	.dp = true,
	.frame_buf_len = numel(g_disp_frame_buf),
	.frame_buf = g_disp_frame_buf,
	.raw_segwrite = board_set_seven_seg
};

//Stream I/O setup
//7-seg output
static int seg_stream_putc(char c, FILE *stream){
	seven_seg_putc(c, &g_disp);
	(void) stream; //Cast to remove unused variable warning
	return 0;
}
FILE seg_str = FDEV_SETUP_STREAM(seg_stream_putc, NULL, _FDEV_SETUP_WRITE);

//Debug UART output
static int debug_stream_putc(char c, FILE *stream){
	boart_uart_putc(c);
	(void) stream;	//Cast to remove unused variable warning
	return 0;
}
FILE uart_str = FDEV_SETUP_STREAM(debug_stream_putc, NULL, _FDEV_SETUP_WRITE);

//Raw rotary encoder driver
struct rotary_enc_t g_rot_enc = {
	.enc_rot_callback = main_rot_callback,
	.enc_btn_callback = main_btn_callback,
	.enc_get_rotstate = board_get_enc,
	.enc_get_btnstate = board_get_encbtn,
	.btn_bounce_int_thrs = BOARD_DEBOUNCE_INT_THRS,
	.enc_divisor = BOARD_ENC_DIVISOR
};

//Menu setup
struct enc_menu_fifo_t g_menu_fifo = {
	.head = 0,
	.tail = 0
	//Mem element does not need to be initialized as FIFO is empty
};

//Measured temperature value screen (initial screen), displays current measured temperature
struct enc_menu_screen_t scr_tct = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = enc_callback_tct_idle,
	.press_screen = NULL,
	.release_screen = &scr_tlo,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Use title string from g ram param struct

//Title low temp. screen
struct enc_menu_screen_t scr_tlo = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = NULL,

	.idle_str = NULL,
	.enter_str = g_flex_ram_param[PARAM_TLO_IDX].title,	//We're using an unsafe access to the title parameter, but as this is constant this is OK

	.press_screen = NULL,
	.release_screen = &scr_tlo_p,
	.cw_screen = &scr_thi,
	.ccw_screen = &scr_sdl
};

//Title high temp. screen
struct enc_menu_screen_t scr_thi = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = NULL,

	.idle_str = NULL,
	.enter_str = g_flex_ram_param[PARAM_THI_IDX].title,

	.press_screen = NULL,
	.release_screen = &scr_thi_p,
	.cw_screen = &scr_thy,
	.ccw_screen = &scr_tlo
};

//Title hysteresis temp. screen
struct enc_menu_screen_t scr_thy = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = NULL,

	.idle_str = NULL,
	.enter_str = g_flex_ram_param[PARAM_THY_IDX].title,

	.press_screen = NULL,
	.release_screen = &scr_thy_p,
	.cw_screen = &scr_plo,
	.ccw_screen = &scr_thi
};

//Title low power screen
struct enc_menu_screen_t scr_plo = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = NULL,

	.idle_str = NULL,
	.enter_str = g_flex_ram_param[PARAM_PLO_IDX].title,

	.press_screen = NULL,
	.release_screen = &scr_plo_p,
	.cw_screen = &scr_phi,
	.ccw_screen = &scr_thy
};

//Title high power screen
struct enc_menu_screen_t scr_phi = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = NULL,

	.idle_str = NULL,
	.enter_str = g_flex_ram_param[PARAM_PHI_IDX].title,

	.press_screen = NULL,
	.release_screen = &scr_phi_p,
	.cw_screen = &scr_pct,
	.ccw_screen = &scr_plo
};

//Title cutoff power screen
struct enc_menu_screen_t scr_pct = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = NULL,

	.idle_str = NULL,
	.enter_str = g_flex_ram_param[PARAM_PCT_IDX].title,

	.press_screen = NULL,
	.release_screen = &scr_pct_p,
	.cw_screen = &scr_elo,
	.ccw_screen = &scr_phi
};

//Title low-temperature error screen
struct enc_menu_screen_t scr_elo = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = NULL,

	.idle_str = NULL,
	.enter_str = g_flex_ram_param[PARAM_ELO_IDX].title,

	.press_screen = NULL,
	.release_screen = &scr_elo_p,
	.cw_screen = &scr_ehi,
	.ccw_screen = &scr_pct
};

//Title low-temperature error screen
struct enc_menu_screen_t scr_ehi = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = NULL,

	.idle_str = NULL,
	.enter_str = g_flex_ram_param[PARAM_EHI_IDX].title,

	.press_screen = NULL,
	.release_screen = &scr_ehi_p,
	.cw_screen = &scr_sdl,
	.ccw_screen = &scr_elo
};

//Title minimum switch delay screen
struct enc_menu_screen_t scr_sdl = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = NULL,

	.idle_str = NULL,
	.enter_str = g_flex_ram_param[PARAM_SDL_IDX].title,

	.press_screen = NULL,
	.release_screen = &scr_sdl_p,
	.cw_screen = &scr_tlo,
	.ccw_screen = &scr_ehi
};

//Internal screen used only for temporary variable storage
struct enc_menu_screen_t scr_temp_int = {
	.enter_callback = NULL,
	.leave_callback = NULL,
	.press_callback = NULL,
	.release_callback = NULL,
	.rot_callback = NULL,
	.idle_callback = NULL,
	
	.idle_str = NULL,
	.enter_str = NULL,
	
	.press_screen = NULL,
	.release_screen = NULL,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Parameter low temp. screen
struct enc_menu_screen_t scr_tlo_p = {
	.enter_callback = enc_callback_enter_p,
	.leave_callback = enc_callback_save_p,
	.press_callback = enc_callback_push_p,
	.release_callback = NULL,
	.rot_callback = enc_callback_rot_p,
	.idle_callback = NULL,
		
	.idle_str = NULL,
	.enter_str = NULL,
		
	.press_screen = NULL,
	.release_screen = &scr_tct,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Parameter high temp. screen
struct enc_menu_screen_t scr_thi_p = {
	.enter_callback = enc_callback_enter_p,
	.leave_callback = enc_callback_save_p,
	.press_callback = enc_callback_push_p,
	.release_callback = NULL,
	.rot_callback = enc_callback_rot_p,
	.idle_callback = NULL,
	
	.idle_str = NULL,
	.enter_str = NULL,
	
	.press_screen = NULL,
	.release_screen = &scr_tct,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Parameter temp. hyst screen
struct enc_menu_screen_t scr_thy_p = {
	.enter_callback = enc_callback_enter_p,
	.leave_callback = enc_callback_save_p,
	.press_callback = enc_callback_push_p,
	.release_callback = NULL,
	.rot_callback = enc_callback_rot_p,
	.idle_callback = NULL,
	
	.idle_str = NULL,
	.enter_str = NULL,
	
	.press_screen = NULL,
	.release_screen = &scr_tct,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Parameter low power screen
struct enc_menu_screen_t scr_plo_p = {
	.enter_callback = enc_callback_enter_p,
	.leave_callback = enc_callback_save_p,
	.press_callback = enc_callback_push_p,
	.release_callback = NULL,
	.rot_callback = enc_callback_rot_p,
	.idle_callback = NULL,
	
	.idle_str = NULL,
	.enter_str = NULL,
	
	.press_screen = NULL,
	.release_screen = &scr_tct,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Parameter high power screen
struct enc_menu_screen_t scr_phi_p = {
	.enter_callback = enc_callback_enter_p,
	.leave_callback = enc_callback_save_p,
	.press_callback = enc_callback_push_p,
	.release_callback = NULL,
	.rot_callback = enc_callback_rot_p,
	.idle_callback = NULL,
	
	.idle_str = NULL,
	.enter_str = NULL,
	
	.press_screen = NULL,
	.release_screen = &scr_tct,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Parameter power cutoff screen
struct enc_menu_screen_t scr_pct_p = {
	.enter_callback = enc_callback_enter_p,
	.leave_callback = enc_callback_save_p,
	.press_callback = enc_callback_push_p,
	.release_callback = NULL,
	.rot_callback = enc_callback_rot_p,
	.idle_callback = NULL,
	
	.idle_str = NULL,
	.enter_str = NULL,
	
	.press_screen = NULL,
	.release_screen = &scr_tct,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Parameter low-temperature error screen
struct enc_menu_screen_t scr_elo_p = {
	.enter_callback = enc_callback_enter_p,
	.leave_callback = enc_callback_save_p,
	.press_callback = enc_callback_push_p,
	.release_callback = NULL,
	.rot_callback = enc_callback_rot_p,
	.idle_callback = NULL,
			
	.idle_str = NULL,
	.enter_str = NULL,
			
	.press_screen = NULL,
	.release_screen = &scr_tct,
	.cw_screen = NULL,
	.ccw_screen = NULL
};
//Parameter high-temperature error screen
struct enc_menu_screen_t scr_ehi_p = {
	.enter_callback = enc_callback_enter_p,
	.leave_callback = enc_callback_save_p,
	.press_callback = enc_callback_push_p,
	.release_callback = NULL,
	.rot_callback = enc_callback_rot_p,
	.idle_callback = NULL,
	
	.idle_str = NULL,
	.enter_str = NULL,
	
	.press_screen = NULL,
	.release_screen = &scr_tct,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Parameter failsafe state screen
struct enc_menu_screen_t scr_fss_p = {
	.enter_callback = enc_callback_enter_p,
	.leave_callback = enc_callback_save_p,
	.press_callback = enc_callback_push_p,
	.release_callback = NULL,
	.rot_callback = enc_callback_rot_p,
	.idle_callback = NULL,
	
	.idle_str = NULL,
	.enter_str = NULL,
	
	.press_screen = NULL,
	.release_screen = &scr_tct,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Parameter switch delay screen
struct enc_menu_screen_t scr_sdl_p = {
	.enter_callback = enc_callback_enter_p,
	.leave_callback = enc_callback_save_p,
	.press_callback = enc_callback_push_p,
	.release_callback = NULL,
	.rot_callback = enc_callback_rot_p,
	.idle_callback = NULL,
	
	.idle_str = NULL,
	.enter_str = NULL,
	
	.press_screen = NULL,
	.release_screen = &scr_tct,
	.cw_screen = NULL,
	.ccw_screen = NULL
};

//Dummy putc function for string output from menu system. Generates \r and \n as needed.
static void dummy_puts(char * str){
	fprintf_P(&seg_str, PSTR("\r%s\n"),str);
}

//Master menu structure
struct enc_menu_master_t g_menu = {
	.inp_fifo = &g_menu_fifo,
	.curr_screen = &scr_tct,
	.puts = dummy_puts
};