/** @file Contains all hardware-specific set-up and accessors */ 

#ifndef BOARD_H_
#define BOARD_H_

#include <stdbool.h>
#include "seven_seg.h"

/** @brief Number of seven-segment displays on board */
#define DISP_NUMSEG	3

#define TIMER_vect	TCC4_CCA_vect
#define DISP_vect	TCC5_CCA_vect

/** @brief Enables all interrupt levels in the PMIC */
void board_en_pmic_all(void);

/** @brief Drives the high-current output for the temperature sensor to the set state */
void board_ts_drive_high(const bool out_en);

/** @brief Drives a normal current (open-drain) state on the temperature sensor bus */
void board_ts_write_state(const bool state);

/** @brief Returns the current temperature sensor bus state */
bool board_ts_get_state(void);

/** @brief Returns true if the reset source was due to WDT reset or brownout reset */
bool board_get_error_reset(void);

/** @brief Initializes all system timers and sets up their priorities */
void board_init_timer(void);

/** @brief Initializes and sets up the clock source */
void board_init_clk(void);

/** @brief Sets up all IO pins for final operation */
void board_init_io(void);

/** @brief Sets the output power switch to a state */
void board_set_output(const bool output_en);

/** @brief Sets the diagnostic output to an error state */
void board_set_errstate(const bool errstate);

/** @brief Gets the current error state of the power switch */
bool board_get_swerr(void);

/** @brief Initializes the UART module for debug message transmission */
void board_uart_init(void);

/** @brief Queues a byte of data for UART transmission, blocking until free */
void boart_uart_putc(char data);

/** @brief Gets the current encoder state */
void board_get_enc(bool * const a, bool * const b);

/** @brief Gets the current encoder button state */
bool board_get_encbtn(void);

/** @brief Activates display n with raw data seg_raw, using encoding defined in seven_seg.h */
void board_set_seven_seg(const seven_seg_num_disp_t n, const uint_least8_t seg_raw);

#endif /* BOARD_H_ */